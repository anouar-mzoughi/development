package com.scool.web.framework;

import java.util.Optional;

public interface ISelectionListener<T> {

	void setSelection(Class<T> clazz, Optional<T> selected);

}
