package com.scool.web.data.service.exception;

public class LogoutException extends Exception {

	private static final long serialVersionUID = 8463469808399458127L;

	public LogoutException(String message) {
		super(message);
	}

}
