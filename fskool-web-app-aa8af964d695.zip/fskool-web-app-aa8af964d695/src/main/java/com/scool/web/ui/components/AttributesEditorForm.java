package com.scool.web.ui.components;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Optional;

import com.scool.web.framework.FrameworkUtils;
import com.scool.web.framework.ISelectionListener;
import com.scool.web.ui.utils.LumoStyles;
import com.scool.web.ui.utils.UIUtils;
import com.vaadin.flow.component.AbstractField;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.Binder;
import com.vaadin.flow.shared.util.SharedUtil;

public class AttributesEditorForm<T> extends FormLayout implements ISelectionListener<T> {

    private static final long serialVersionUID = -2115554449621892310L;

    private final Binder<T> binder;
    private IFormActionsListener<T> actionsListener;

    public AttributesEditorForm(Class<T> clazz, IFormActionsListener<T> listener) {
        binder = new Binder<>(clazz);
        actionsListener = listener;
        // addClassName("edit-form");
        createForm();
        createFormFields(clazz);
        // createActionsLine(clazz, form);
    }

    private void createForm() {
        addClassNames(LumoStyles.Padding.Bottom.L, LumoStyles.Padding.Horizontal.L, LumoStyles.Padding.Top.S);

        setResponsiveSteps(new FormLayout.ResponsiveStep("0", 1, FormLayout.ResponsiveStep.LabelsPosition.TOP),
                new FormLayout.ResponsiveStep("21em", 2, FormLayout.ResponsiveStep.LabelsPosition.TOP));
    }

    private void createFormFields(Class<T> clazz) {
        List<String> columnPropertyNames = FrameworkUtils.getClassPropertyNames(clazz);
        columnPropertyNames.forEach(fn -> createFieldFor(this, fn, clazz));
    }

    public Component createActionsLine(Class<T> clazz) {
        Button save = UIUtils.createPrimaryButton("Save");
        Button delete = UIUtils.createErrorButton("Delete");
        Button close = UIUtils.createTertiaryButton("Cancel");

        save.addClickListener(e -> save(clazz, binder.getBean()));
        delete.addClickListener(e -> delete(clazz, binder.getBean()));
        close.addClickListener(e -> cancel(clazz, binder.getBean()));

        HorizontalLayout buttons = new HorizontalLayout(save, close, delete);
        buttons.addClassName("spacing-r-s");
        return buttons;
    }

    public void setEntity(T t, Class<T> clazz) {
        binder.setBean(t);
    }

    @Override
    public void setSelection(Class<T> clazz, Optional<T> selected) {
        setEntity(selected.orElse(null), clazz);
    }

    protected void createFieldFor(FormLayout form, String fieldName, Class<T> clazz) {
        Optional<AbstractField<?, ?>> field = createField(fieldName, clazz);
        if (field.isPresent()) {
            binder.bind(field.get(), fieldName);
            form.addFormItem(field.get(), SharedUtil.propertyIdToHumanFriendly(fieldName));
        }
    }

    protected Optional<AbstractField<?, ?>> createField(String fieldName, Class<T> clazz) {
        Field declaredField = null;
        try {
            declaredField = clazz.getDeclaredField(fieldName);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        } catch (SecurityException e) {
            e.printStackTrace();
        }
        if (declaredField != null && String.class.isAssignableFrom(declaredField.getType())) {
            TextField textField = new TextField();
            textField.setWidthFull();
            return Optional.of(textField);
        }
        return Optional.empty();
    }

    private Object save(Class<T> clazz, T bean) {
        return actionsListener.save(clazz, bean);
    }

    private Object delete(Class<T> clazz, T bean) {
        return actionsListener.delete(clazz, bean);
    }

    private Object cancel(Class<T> clazz, T bean) {
        return actionsListener.cancel(clazz, bean);
    }

    public static interface IFormActionsListener<T> {
        Object save(Class<T> clazz, T bean);

        Object delete(Class<T> clazz, T bean);

        Object cancel(Class<T> clazz, T bean);
    }

}
