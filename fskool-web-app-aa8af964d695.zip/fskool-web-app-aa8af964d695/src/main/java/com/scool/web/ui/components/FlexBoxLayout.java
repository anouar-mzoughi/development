package com.scool.web.ui.components;

import com.google.common.collect.Lists;
import com.scool.web.ui.layout.Size;
import com.scool.web.ui.utils.css.BorderRadius;
import com.scool.web.ui.utils.css.BoxSizing;
import com.scool.web.ui.utils.css.Display;
import com.scool.web.ui.utils.css.Overflow;
import com.scool.web.ui.utils.css.Position;
import com.scool.web.ui.utils.css.Shadow;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.orderedlayout.FlexLayout;
import com.vaadin.flow.theme.lumo.Lumo;

import java.util.ArrayList;

public class FlexBoxLayout extends FlexLayout {

	private static final long serialVersionUID = -5175364786422643005L;
	public static final String BACKGROUND_COLOR = "background-color";
	public static final String BORDER_RADIUS = "border-radius";
	public static final String BOX_SHADOW = "box-shadow";
	public static final String BOX_SIZING = "box-sizing";
	public static final String DISPLAY = "display";
	public static final String FLEX_DIRECTION = "flex-direction";
	public static final String FLEX_WRAP = "flex-wrap";
	public static final String MAX_WIDTH = "max-width";
	public static final String OVERFLOW = "overflow";
	public static final String POSITION = "position";

	private ArrayList<Size> spacings = Lists.newArrayList();

	public FlexBoxLayout() {
		super();
	}

	public FlexBoxLayout(Component... components) {
		super(components);
	}

	public void setBackgroundColor(String value) {
		getStyle().set(BACKGROUND_COLOR, value);
	}

	public void setBackgroundColor(String value, String theme) {
		getStyle().set(BACKGROUND_COLOR, value);
		setTheme(theme);
	}

	public void removeBackgroundColor() {
		getStyle().remove(BACKGROUND_COLOR);
	}

	public void setBorderRadius(BorderRadius radius) {
		getStyle().set(BORDER_RADIUS, radius.getValue());
	}

	public void removeBorderRadius() {
		getStyle().remove(BORDER_RADIUS);
	}

	public void setBoxSizing(BoxSizing sizing) {
		getStyle().set(BOX_SIZING, sizing.getValue());
	}

	public void removeBoxSizing() {
		getStyle().remove(BOX_SIZING);
	}

	public void setDisplay(Display display) {
		getStyle().set(DISPLAY, display.getValue());
	}

	public void removeDisplay() {
		getStyle().remove(DISPLAY);
	}

	public void setFlex(String value, Component... components) {
		for (Component component : components) {
			component.getElement().getStyle().set("flex", value);
		}
	}

	public void setFlexBasis(String value, Component... components) {
		for (Component component : components) {
			component.getElement().getStyle().set("flex-basis", value);
		}
	}

	public void setFlexDirection(com.scool.web.ui.utils.css.FlexDirection direction) {
		getStyle().set(FLEX_DIRECTION, direction.getValue());
	}

	public void removeFlexDirection() {
		getStyle().remove(FLEX_DIRECTION);
	}

	public void setFlexShrink(String value, Component... components) {
		for (Component component : components) {
			component.getElement().getStyle().set("flex-shrink", value);
		}
	}

	public void setFlexWrap(com.scool.web.ui.utils.css.FlexWrap wrap) {
		getStyle().set(FLEX_WRAP, wrap.getValue());
	}

	public void removeFlexWrap() {
		getStyle().remove(FLEX_WRAP);
	}

	public void setMargin(Size... sizes) {
		for (Size size : sizes) {
			for (String attribute : size.getMarginAttributes()) {
				getStyle().set(attribute, size.getVariable());
			}
		}
	}

	public void removeMargin() {
		getStyle().remove("margin");
		getStyle().remove("margin-bottom");
		getStyle().remove("margin-left");
		getStyle().remove("margin-right");
		getStyle().remove("margin-top");
	}

	public void setMaxWidth(String value) {
		getStyle().set(MAX_WIDTH, value);
	}

	public void removeMaxWidth() {
		getStyle().remove(MAX_WIDTH);
	}

	public void setOverflow(Overflow overflow) {
		getStyle().set(OVERFLOW, overflow.getValue());
	}

	public void removeOverflow() {
		getStyle().remove(OVERFLOW);
	}

	public void setPadding(Size... sizes) {
		removePadding();
		for (Size size : sizes) {
			for (String attribute : size.getPaddingAttributes()) {
				getStyle().set(attribute, size.getVariable());
			}
		}
	}

	public void removePadding() {
		getStyle().remove("padding");
		getStyle().remove("padding-bottom");
		getStyle().remove("padding-left");
		getStyle().remove("padding-right");
		getStyle().remove("padding-top");
	}

	public void setPosition(Position position) {
		getStyle().set(POSITION, position.getValue());
	}

	public void removePosition() {
		getStyle().remove(POSITION);
	}

	public void setShadow(Shadow shadow) {
		getStyle().set(BOX_SHADOW, shadow.getValue());
	}

	public void removeShadow() {
		getStyle().remove(BOX_SHADOW);
	}

	public void setSpacing(Size... sizes) {
		// Remove old styles (if applicable)
		for (Size spacing : spacings) {
			removeClassName(spacing.getSpacingClassName());
		}
		spacings.clear();

		// Add new
		for (Size size : sizes) {
			addClassName(size.getSpacingClassName());
			spacings.add(size);
		}
	}

	public void setTheme(String theme) {
		if (Lumo.DARK.equals(theme)) {
			getElement().setAttribute("theme", "dark");
		} else {
			getElement().removeAttribute("theme");
		}
	}
}
