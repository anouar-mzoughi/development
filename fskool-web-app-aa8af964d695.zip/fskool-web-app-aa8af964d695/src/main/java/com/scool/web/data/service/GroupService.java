package com.scool.web.data.service;

import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.stereotype.Service;

import com.scool.web.data.entity.Group;
import com.scool.web.data.service.remote.IDataServerRemoteService;
import com.scool.web.framework.services.DataService;
import com.scool.web.framework.services.IDataRemoteService;

@Service
public class GroupService extends DataService<Group> {

	public GroupService(IDataServerRemoteService service) {
		super(new GroupServiceProxy(service));
	}

	private static final class GroupServiceProxy implements IDataRemoteService<Group> {
		private final IDataServerRemoteService service;
		
		

		public GroupServiceProxy(IDataServerRemoteService service) {
			this.service = service;
		}

		@Override
		public CollectionModel<Group> all() {
			return service.allGroups();
		}

		@Override
		public EntityModel<Group> get(Long id) {
			return service.getGroup(id);
		}

		@Override
		public Group update(String id, Group access) {
			return service.updateGroup(id, access);
		}

		@Override
		public Group add(Group access) {
			return service.addGroup(access);
		}

		@Override
		public Group delete(String id) {
			return service.deleteGroup(id);
		}
	}
}
