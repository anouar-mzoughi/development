package com.scool.web.framework.data;

import java.util.Objects;

/**
 * The Interface IWithIdentifier.
 */
public interface IWithIdentifier {

    /**
     * Gets the identifier.
     *
     * @return the identifier
     */
    public Long getIdentifier();

    /**
     * Sets the identifier.
     *
     * @param id
     *            the new identifier
     */
    public void setIdentifier(Long id);

    /**
     * Checks if is persisted.
     *
     * @return true, if is persisted
     */
    default boolean isPersisted() {
        return Objects.nonNull(getIdentifier());
    }
}
