package com.scool.web.data.service.remote;

import java.util.Optional;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.scool.web.ui.utils.Consts;
import com.vaadin.flow.component.UI;

import feign.RequestInterceptor;
import feign.RequestTemplate;

@Configuration
class LoginServerConfiguration {

    @Bean
    public RequestInterceptor authenticationInterceptor() {
        return new X();

    }

    class X implements RequestInterceptor {

        @Override
        public void apply(RequestTemplate template) {
            Object attribute = UI.getCurrent().getSession().getAttribute(Consts.SESSION_TOKEN);
            Optional
                .ofNullable(attribute)
                .map(String.class::cast)
                .ifPresent(token -> template.header("Authorization", token));
        }

    }
}
