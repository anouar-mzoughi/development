package com.scool.web.ui.views.authentication;

import java.util.Objects;

import org.springframework.lang.NonNull;

import com.google.common.base.Strings;
import com.scool.web.data.service.AuthenticationService;
import com.scool.web.data.service.exception.RegisterException;
import com.scool.web.ui.utils.UIUtils;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.textfield.PasswordField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

@Route("register")
@PageTitle("Register")
@CssImport("./styles/views/register/register-view.css")
public class RegisterView extends Div {

	private static final long serialVersionUID = 7519574429189462271L;

	public RegisterView(@NonNull AuthenticationService authService) {
		setId("register-view");
		TextField username = new TextField("Username");
		TextField activationCode = new TextField("Activation Code");
		PasswordField password = new PasswordField("Password");
		PasswordField confirmPassword = new PasswordField("Confirm Password");
		Button btnRegister = UIUtils.createPrimaryButton("Register");
		btnRegister.addClickListener(event -> register(authService, username.getValue(), password.getValue(),
				confirmPassword.getValue(), activationCode.getValue()));

		Button btnLogin = UIUtils.createTertiaryButton("Back to Login");
		btnLogin.addClickListener(event -> UI.getCurrent().navigate(LoginView.class));

		add(new H1(" Register in Scool!"), username, password, confirmPassword, activationCode, btnRegister, btnLogin);
	}

	private void register(AuthenticationService authService, String userId, String password, String confirmation,
			String code) {
		if (Strings.isNullOrEmpty(userId) || Strings.isNullOrEmpty(password) || Strings.isNullOrEmpty(confirmation)
				|| Strings.isNullOrEmpty(code)) {
			Notification.show("Wrong credentials! Please check your Input.");
			return;
		}
		if (!Objects.equals(password, confirmation)) {
			Notification.show("Password and Confirmation does not match!");
			return;
		}

		try {
			authService.register(userId, password, code);
			UI.getCurrent().navigate(LoginView.class);
		} catch (RegisterException e) {
			Notification.show(e.getMessage());
			e.printStackTrace();
		}
	}
}
