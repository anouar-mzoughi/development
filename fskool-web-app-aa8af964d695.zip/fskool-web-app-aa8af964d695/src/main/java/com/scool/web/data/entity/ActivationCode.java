package com.scool.web.data.entity;

import com.scool.web.framework.data.AbstractEntity;

public class ActivationCode extends AbstractEntity {

	private String code ;
	private Long personId;

	public ActivationCode() {
		//
	}
	
	public ActivationCode(Long personId) {
		this.personId = personId;
	}
	
	public ActivationCode(String code) {
		this.code = code;
	}

	public ActivationCode(Long id, String code, Long person) {
		super(id);
		this.code = code;
		this.personId = person;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Long getPersonId() {
		return personId;
	}

	public void setPersonId(Long person) {
		this.personId = person;
	}

}
