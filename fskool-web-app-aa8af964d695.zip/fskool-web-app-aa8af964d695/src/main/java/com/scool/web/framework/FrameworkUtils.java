package com.scool.web.framework;

import java.lang.reflect.Field;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FrameworkUtils {

	public static <T> List<String> getClassPropertyNames(Class<T> clazz) {
		return Stream.of(clazz.getDeclaredFields()).map(Field::getName).collect(Collectors.toList());
	}
	
}
