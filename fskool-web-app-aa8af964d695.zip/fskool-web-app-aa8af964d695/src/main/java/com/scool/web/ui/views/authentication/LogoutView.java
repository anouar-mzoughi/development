package com.scool.web.ui.views.authentication;

import com.scool.web.data.service.AuthenticationService;
import com.scool.web.data.service.exception.LogoutException;
import com.vaadin.flow.component.Composite;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinSession;

@Route("logout")
@PageTitle("Logout")
public class LogoutView extends Composite<VerticalLayout> {

	private static final long serialVersionUID = 6753716662354155846L;

	public LogoutView(AuthenticationService authService) {
		try {
			authService.logout();
		} catch (LogoutException e) {
			UI.getCurrent().getPage().setLocation("home");
			Notification.show(e.getMessage());
			e.printStackTrace();
		}
        UI.getCurrent().getPage().setLocation("login");
        VaadinSession.getCurrent().getSession().invalidate();
        VaadinSession.getCurrent().close();
    }

}