package com.scool.web.data.service;

import java.util.Optional;

import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.stereotype.Service;

import com.scool.web.data.entity.ActivationCode;
import com.scool.web.data.service.remote.ILoginServerRemoteService;
import com.scool.web.framework.services.DataService;
import com.scool.web.framework.services.IDataRemoteService;

/**
 * The Class ActivationCodeService.
 */
@Service
public class ActivationCodeService extends DataService<ActivationCode> {

	/**
	 * Instantiates a new activation code service.
	 *
	 * @param service the service
	 */
	public ActivationCodeService(ILoginServerRemoteService service) {
		super(new ActivationCodeServiceProxy(service));
	}

	/**
	 * The Class ActivationCodeServiceProxy.
	 */
	private static final class ActivationCodeServiceProxy implements IDataRemoteService<ActivationCode> {

		/** The service. */
		private final ILoginServerRemoteService service;

		/**
		 * Instantiates a new activation code service proxy.
		 *
		 * @param service the service
		 */
		public ActivationCodeServiceProxy(ILoginServerRemoteService service) {
			super();
			this.service = service;
		}

		/**
		 * All.
		 *
		 * @return the collection model
		 */
		@Override
		public CollectionModel<ActivationCode> all() {
			return service.allActivationCodes();
		}

		/**
		 * Gets the.
		 *
		 * @param id the id
		 * @return the entity model
		 */
		@Override
		public EntityModel<ActivationCode> get(Long id) {
			return service.getActivationCode(id);
		}

		/**
		 * Update.
		 *
		 * @param id     the id
		 * @param access the access
		 * @return the activation code
		 */
		@Override
		public ActivationCode update(String id, ActivationCode access) {
			return null;
		}

		/**
		 * Adds the.
		 *
		 * @param access the access
		 * @return the activation code
		 */
		@Override
		public ActivationCode add(ActivationCode access) {
			return null;
		}

		/**
		 * Delete.
		 *
		 * @param id the id
		 * @return the activation code
		 */
		@Override
		public ActivationCode delete(String id) {
			return Optional.ofNullable(service.deleteActivationCode(id)).map(e -> e.getContent()).orElse(null);
		}

	}
}
