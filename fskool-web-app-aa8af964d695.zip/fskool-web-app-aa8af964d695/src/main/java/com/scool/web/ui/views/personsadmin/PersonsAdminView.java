package com.scool.web.ui.views.personsadmin;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import com.scool.web.data.entity.ActivationCode;
import com.scool.web.data.entity.Person;
import com.scool.web.data.entity.Role;
import com.scool.web.data.entity.User;
import com.scool.web.data.service.AuthenticationService;
import com.scool.web.data.service.PersonService;
import com.scool.web.data.service.RoleService;
import com.scool.web.data.service.UserService;
import com.scool.web.framework.data.Pair;
import com.scool.web.ui.components.Badge;
import com.scool.web.ui.components.GridEditorView;
import com.scool.web.ui.components.Initials;
import com.scool.web.ui.components.ListItem;
import com.scool.web.ui.components.RelatedEntitiesEditor;
import com.scool.web.ui.layout.Right;
import com.scool.web.ui.layout.Vertical;
import com.scool.web.ui.utils.LumoStyles;
import com.scool.web.ui.utils.UIUtils;
import com.scool.web.ui.utils.css.lumo.BadgeColor;
import com.scool.web.ui.views.main.MainView;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.data.provider.Query;
import com.vaadin.flow.data.renderer.ComponentRenderer;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

/**
 * The Class PersonsAdminView.
 */
@PageTitle("Persons Adminstration")
@Route(value = "persons-admin", layout = MainView.class)
@CssImport("styles/views/personsadmin/personsadmin-view.css")
public class PersonsAdminView extends GridEditorView<Person> {

	/** The roles service. */
	private final RoleService rolesService;
	private final UserService usersService;

	/**
	 * Instantiates a new persons admin view.
	 *
	 * @param pservice              the pservice
	 * @param rolesService          the roles service
	 * @param authenticationService the authentication service
	 */
	public PersonsAdminView(PersonService pservice, RoleService rolesService,
			AuthenticationService authenticationService, UserService usersService) {
		super(Person.class, pservice);
		this.rolesService = rolesService;
		this.usersService = usersService;
	}

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7599941489233459385L;

	/**
	 * Creates the editor pages.
	 *
	 * @param clazz the clazz
	 * @return the list
	 */
	@Override
	protected List<Pair<Tab, Component>> createEditorPages(Class<Person> clazz) {
		List<Pair<Tab, Component>> pages = super.createEditorPages(clazz);
		PersonService personsService = getPersonsService();
		pages.add(Pair.newPair(new Tab("Roles"),
				RelatedEntitiesEditor.newRelatedEntitiesEditor(Person.class, Role.class)
						.firstProvider(this::getSelection).secondRetriever(personsService::getPersonRoles)
						.secondFetchCallBack(this::rolesFetchCallBack).secondLabelMapping(Role::getName)
						.secondContentProvider(Role::getDescription).linkHandler(personsService::addRoleToPerson)
						.unlinkHandler(personsService::removeRoleFromPerson).build()));
		return pages;
	}

	/**
	 * Roles fetch call back.
	 *
	 * @param q the q
	 * @return the stream
	 */
	private Stream<Role> rolesFetchCallBack(Query<Role, String> q) {
		q.getLimit();
		q.getPage();
		return rolesService.fetchAll().stream();
	}

	/**
	 * Gets the persons service.
	 *
	 * @return the persons service
	 */
	protected PersonService getPersonsService() {
		return (PersonService) getDataService();
	}

	/**
	 * Builds the columns.
	 *
	 * @param grid   the grid
	 * @param clazz2 the clazz 2
	 */
	@Override
	protected void buildColumns(Grid<Person> grid, Class<Person> clazz2) {
		grid.removeAllColumns();
		grid.addColumn(new ComponentRenderer<>(this::createUserInfo)).setAutoWidth(true).setHeader("Name");
		grid.addColumn(new ComponentRenderer<>(this::createContact)).setAutoWidth(true).setFlexGrow(0)
				.setHeader("Contact");
		grid.addColumn(new ComponentRenderer<>(this::createActive)).setAutoWidth(true).setFlexGrow(0)
				.setHeader("Active user");
	}

	/**
	 * Creates the user info.
	 *
	 * @param person the person
	 * @return the component
	 */
	private Component createUserInfo(Person person) {
		ListItem item = new ListItem(new Initials(person.getInitials()), person.getFullName(), person.getAddress());
		item.setPadding(Vertical.XS);
		item.setSpacing(Right.M);
		return item;
	}

	/**
	 * Creates the contact.
	 *
	 * @param person the person
	 * @return the component
	 */
	private Component createContact(Person person) {
		ListItem item = new ListItem(person.getEmail(), person.getMobile());
		item.setPadding(Vertical.XS);
		item.setSpacing(Right.M);
		return item;
	}

	/**
	 * Creates the active user column renderer.
	 *
	 * @param person the person
	 * @return the component
	 */
	private Component createActive(Person person) {
		Optional<User> user = usersService.getUserByPersonId(person.getIdentifier());
		if (user.isPresent()) {
			return new Badge("Active", BadgeColor.SUCCESS);
		}
		Optional<ActivationCode> code = usersService.getCodeByPersonId(person.getIdentifier());
		if (code.isPresent()) {
			return new Badge(code.get().getCode(), BadgeColor.NORMAL);
		}

		Button btnActivate = UIUtils.createPrimaryButton("Activate");
		btnActivate.setDisableOnClick(true);
		btnActivate.addClickListener(e -> {
			usersService.activate(person.getIdentifier());
			updateList();
		});
		return btnActivate;
	}
}
