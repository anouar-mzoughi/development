package com.scool.web.data.entity;

import com.scool.web.framework.data.AbstractEntity;

public class Group extends AbstractEntity {

    private String name;

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
}
