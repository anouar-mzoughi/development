package com.scool.web.ui.views.authentication;

import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import com.google.common.collect.Lists;
import com.scool.web.data.service.AuthenticationService;
import com.scool.web.data.service.exception.AuthenticationException;
import com.scool.web.ui.utils.Consts;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.login.LoginI18n;
import com.vaadin.flow.component.login.LoginOverlay;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

@Route(value = "login")
@PageTitle("Login")
@CssImport("./styles/views/login/login-view.css")
public class LoginView extends Div {

	private static final long serialVersionUID = -586548817138799732L;

	private LoginOverlay login = new LoginOverlay();

	public LoginView(AuthenticationService authService) {
		setId("login-view");
		// configures login dialog and adds it to the main view
		login.setOpened(true);
		login.setTitle("Welcome to Scool!");
		login.setDescription("Use your login and password to authenticate");

		LoginI18n loginForm = LoginI18n.createDefault();
		login.setI18n(loginForm);
		loginForm.getForm().setForgotPassword("Register / Sign Up");

		add(login);
		login.addLoginListener(e -> {
			try {
				String token = authService.authenticate(e.getUsername(), e.getPassword());

				UI.getCurrent().getSession().setAttribute(Consts.SESSION_TOKEN, token);
				SecurityContextHolder.getContext().setAuthentication(new AnonymousAuthenticationToken(token,
						e.getUsername(), Lists.newArrayList(new SimpleGrantedAuthority("USER"))));
				login.close();
				UI.getCurrent().navigate("home");
			} catch (AuthenticationException ex) {
				Notification.show("Wrong credentials.");
			}
		});
		login.addForgotPasswordListener(event -> {
			login.close();
			UI.getCurrent().navigate(RegisterView.class);
		});

	}

}
