package com.scool.web.data.service.remote;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.scool.web.data.entity.ActivationCode;
import com.scool.web.data.entity.User;

/**
 * The Interface ILoginServerRemoteService.
 */
@FeignClient(value = "login-server", configuration = LoginServerConfiguration.class)
public interface ILoginServerRemoteService {

	/**
	 * Register.
	 *
	 * @param info the info
	 * @return the string
	 */
	@PostMapping("/auth/register")
	String register(@NonNull @RequestBody RegistrationInfo info);

	/**
	 * The Class RegistrationInfo.
	 */
	public static class RegistrationInfo {

		/** The activation code. */
		private String activationCode;

		/** The username. */
		private String username;

		/** The password. */
		private String password;

		/**
		 * Instantiates a new registration info.
		 *
		 * @param activationCode the activation code
		 * @param username       the username
		 * @param password       the password
		 */
		public RegistrationInfo(String activationCode, String username, String password) {
			this.activationCode = activationCode;
			this.username = username;
			this.password = password;
		}

		/**
		 * Gets the activation code.
		 *
		 * @return the activation code
		 */
		public String getActivationCode() {
			return activationCode;
		}

		/**
		 * Gets the username.
		 *
		 * @return the username
		 */
		public String getUsername() {
			return username;
		}

		/**
		 * Gets the password.
		 *
		 * @return the password
		 */
		public String getPassword() {
			return password;
		}

	}

	/**
	 * Login.
	 *
	 * @param login the login
	 * @return the response entity
	 */
	@PostMapping("/auth/login")
	ResponseEntity<?> login(@RequestBody LoginInfo login);

	/**
	 * The Class LoginInfo.
	 */
	public static class LoginInfo {

		/** The username. */
		private String username;

		/** The password. */
		private String password;

		/**
		 * Instantiates a new login info.
		 *
		 * @param username the username
		 * @param password the password
		 */
		public LoginInfo(String username, String password) {
			this.username = username;
			this.password = password;
		}

		/**
		 * Gets the username.
		 *
		 * @return the username
		 */
		public String getUsername() {
			return username;
		}

		/**
		 * Gets the password.
		 *
		 * @return the password
		 */
		public String getPassword() {
			return password;
		}

	}

	/**
	 * All users.
	 *
	 * @return the list
	 */
	@GetMapping(value = "/auth/users")
	List<User> allUsers();

	/**
	 * Gets the user.
	 *
	 * @param id the id
	 * @return the user
	 */
	@GetMapping(value = "/auth/users/{id}")
	User getUser(@NonNull @PathVariable Long id);

	/**
	 * Gets the user by person id.
	 *
	 * @param id the id
	 * @return the user by person id
	 */
	@GetMapping("/auth/users/byPersonId/{id}")
	User getUserByPersonId(@NonNull @PathVariable Long id);

	/**
	 * Update user.
	 *
	 * @param id     the id
	 * @param access the access
	 * @return the user
	 */
	@PutMapping(value = "/auth/users/{id}")
	User updateUser(@NonNull @PathVariable String id, @NonNull @RequestBody User access);

	/**
	 * Adds the user.
	 *
	 * @param access the access
	 * @return the user
	 */
	@PostMapping(value = "/auth/users/")
	User addUser(@NonNull @RequestBody User access);

	/**
	 * Delete user.
	 *
	 * @param id the id
	 * @return the user
	 */
	@DeleteMapping(value = "/auth/users/{id}")
	User deleteUser(@NonNull @PathVariable String id);

	/**
	 * Activate.
	 *
	 * @param id the id
	 * @return the response entity
	 */
	@GetMapping("/auth/activate/{id}")
	ResponseEntity<ActivationCode> activate(@NonNull @PathVariable Long id);

	/**
	 * All activation codes.
	 *
	 * @return the collection model
	 */
	@GetMapping("/activationCodes")
	CollectionModel<ActivationCode> allActivationCodes();

	/**
	 * Gets the activation code.
	 *
	 * @param id the id
	 * @return the activation code
	 */
	@GetMapping(value = "/activationCodes/{id}")
	EntityModel<ActivationCode> getActivationCode(@NonNull @PathVariable Long id);

	@GetMapping("auth/activationCodes/byPersonId/{id}")
	ResponseEntity<ActivationCode> getActivationCodeByPersonId(@PathVariable Long id);

	@DeleteMapping("/activationCodes/{id}")
	EntityModel<ActivationCode> deleteActivationCode(@PathVariable String id);
}
