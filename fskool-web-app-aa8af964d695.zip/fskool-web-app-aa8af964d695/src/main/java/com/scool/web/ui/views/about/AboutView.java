package com.scool.web.ui.views.about;

import com.scool.web.ui.views.main.MainView;
import com.vaadin.flow.component.Text;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

@Route(value = "about", layout = MainView.class)
@PageTitle("About")
public class AboutView extends Div {

	private static final long serialVersionUID = 2080078959181595594L;

	public AboutView() {
        setId("about-view");
        add(new Text("Content placeholder"));
    }

}
