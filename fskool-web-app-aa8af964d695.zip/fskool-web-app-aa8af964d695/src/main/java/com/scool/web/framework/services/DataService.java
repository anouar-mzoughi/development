package com.scool.web.framework.services;

import static java.util.Objects.nonNull;

import java.util.List;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;

import com.google.common.base.Joiner;
import com.google.common.collect.ImmutableList;
import com.scool.web.framework.data.IWithIdentifier;

/**
 * The Class DataService.
 *
 * @param <T>
 *            the generic type
 */
public class DataService<T extends IWithIdentifier> implements IDataService<T> {

    /** The remote data service. */
    private final IDataRemoteService<T> remoteDataService;

    /**
     * Instantiates a new data service.
     *
     * @param remoteDataService
     *            the remote data service
     */
    public DataService(IDataRemoteService<T> remoteDataService) {
        this.remoteDataService = remoteDataService;
    }

    /**
     * Save.
     *
     * @param t
     *            the t
     * @return the t
     */
    @Override
    public T save(T t) {
        Optional<Long> id = Optional.ofNullable(t.getIdentifier());
        if (id.isPresent()) {
            return remoteDataService.update(String.valueOf(id.get()), t);
        } else {
            return remoteDataService.add(t);
        }
    }

    /**
     * Delete.
     *
     * @param t
     *            the t
     * @return the t
     */
    @Override
    public T delete(T t) {
        if (nonNull(t.getIdentifier())) {

        }
        return remoteDataService.delete(String.valueOf(t.getIdentifier()));
    }

    /**
     * Fetch all.
     *
     * @return the list
     */
    @Override
    public List<T> fetchAll() {
        return ImmutableList.copyOf(remoteDataService.all().getContent());
    }

    /**
     * Gets the remote data service.
     *
     * @return the remote data service
     */
    public IDataRemoteService<T> getRemoteDataService() {
        return remoteDataService;
    }

    /**
     * Adds the Entity A to T (REST Linking).
     *
     * @param <T>
     *            the generic type
     * @param <A>
     *            the generic type
     * @param t
     *            the t
     * @param a
     *            the a
     * @param aProvider
     *            the a provider
     * @param aModelMapper
     *            the a model mapper
     * @param linker
     *            the linker
     */
    protected static <T extends IWithIdentifier, A extends IWithIdentifier> void addAtoT(T t, A a,
            Function<Long, CollectionModel<A>> aProvider, Function<Long, EntityModel<A>> aModelMapper,
            BiConsumer<Long, String> linker) {

        if (!a.isPersisted() || !t.isPersisted()) {
            return; // TODO Throw an exception
        }

        if (aProvider
            .apply(t.getIdentifier())
            .getContent()
            .stream()
            .map(IWithIdentifier::getIdentifier)
            .anyMatch(a.getIdentifier()::equals)) {
            return; // TODO Throw an exception Item already exists
        }

        linker
            .accept(t.getIdentifier(),
                    aModelMapper.apply(a.getIdentifier()).getLink("self").get().toUri().toASCIIString());
    }

    /**
     * Removes the afrom T.
     *
     * @param <T> the generic type
     * @param <A> the generic type
     * @param t the t
     * @param a the a
     * @param aProvider the a provider
     * @param aModelMapper the a model mapper
     * @param linker the linker
     */
    protected static <T extends IWithIdentifier, A extends IWithIdentifier> void removeAfromT(T t, A a,
            Function<Long, CollectionModel<A>> aProvider, Function<Long, EntityModel<A>> aModelMapper,
            BiConsumer<Long, String> linker) {
        
        if (!a.isPersisted() || !t.isPersisted()) {
            return; // TODO Throw an exception
        }

        List<String> links = aProvider
            .apply(t.getIdentifier())
            .getContent()
            .stream()
            .filter(r -> r.getIdentifier().equals(a.getIdentifier()))
            .map(r -> aModelMapper.apply(r.getIdentifier()).getLink("self").get().toUri().toASCIIString())
            .collect(Collectors.toList());

        linker.accept(t.getIdentifier(), Joiner.on("\r\n").join(links));
    }
}
