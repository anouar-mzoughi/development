package com.scool.web.data.service.remote;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.scool.web.data.entity.Access;
import com.scool.web.data.entity.Group;
import com.scool.web.data.entity.Person;
import com.scool.web.data.entity.Role;

@FeignClient(value = "data-server")
public interface IDataServerRemoteService
         {
    /**
     * All acessess.
     *
     * @return the collection model
     */
    @GetMapping(value = "/accesses")
    CollectionModel<Access> allAcessess();

    /**
     * Gets the access.
     *
     * @param id the id
     * @return the access
     */
    @GetMapping(value = "/accesses/{id}")
    EntityModel<Access> getAccess(@NonNull @PathVariable Long id);

    /**
     * Update access.
     *
     * @param id the id
     * @param access the access
     * @return the access
     */
    @PutMapping(value = "/accesses/{id}")
    Access updateAccess(@NonNull @PathVariable String id, @NonNull @RequestBody Access access);

    /**
     * Adds the access.
     *
     * @param access the access
     * @return the access
     */
    @PostMapping(value = "/accesses/")
    Access addAccess(@NonNull @RequestBody Access access);

    /**
     * Delete access.
     *
     * @param id the id
     * @return the access
     */
    @DeleteMapping(value = "/accesses/{id}")
    Access deleteAccess(@NonNull @PathVariable String id);
    
    /**
     * All groups.
     *
     * @return the collection model
     */
    @GetMapping(value = "/groups")
    CollectionModel<Group> allGroups();

    /**
     * Gets the group.
     *
     * @param id the id
     * @return the group
     */
    @GetMapping(value = "/groups/{id}")
    EntityModel<Group> getGroup(@NonNull @PathVariable Long id);

    /**
     * Update group.
     *
     * @param id the id
     * @param access the access
     * @return the group
     */
    @PutMapping(value = "/groups/{id}")
    Group updateGroup(@NonNull @PathVariable String id, @NonNull @RequestBody Group access);

    /**
     * Adds the group.
     *
     * @param access the access
     * @return the group
     */
    @PostMapping(value = "/groups/")
    Group addGroup(@NonNull @RequestBody Group access);

    /**
     * Delete group.
     *
     * @param id the id
     * @return the group
     */
    @DeleteMapping(value = "/groups/{id}")
    Group deleteGroup(@NonNull @PathVariable String id);
    
    /**
     * All persons.
     *
     * @return the collection model
     */
    @GetMapping(value = "/persons")
    CollectionModel<Person> allPersons();

    /**
     * Gets the person.
     *
     * @param id the id
     * @return the person
     */
    @GetMapping(value = "/persons/{id}")
    EntityModel<Person> getPerson(@NonNull @PathVariable Long id);

    /**
     * Gets the person roles.
     *
     * @param id the id
     * @return the person roles
     */
    @GetMapping(value = "/persons/{id}/roles")
    CollectionModel<Role> getPersonRoles(@NonNull @PathVariable Long id);
    
    /**
     * Update person.
     *
     * @param id the id
     * @param access the access
     * @return the person
     */
    @PutMapping(value = "/persons/{id}")
    Person updatePerson(@NonNull @PathVariable String id, @NonNull @RequestBody Person access);

    /**
     * Adds the person.
     *
     * @param access the access
     * @return the person
     */
    @PostMapping(value = "/persons/")
    Person addPerson(@NonNull @RequestBody Person access);

    /**
     * Delete person.
     *
     * @param id the id
     * @return the person
     */
    @DeleteMapping(value = "/persons/{id}")
    Person deletePerson(@NonNull @PathVariable String id);

    /**
     * Adds the role to person.
     *
     * @param id the id
     * @param role the role
     * @return the person
     */
    @PostMapping(value = "/persons/{id}/roles", consumes = "text/uri-list")
    Person addRoleToPerson(@PathVariable Long id, @RequestBody String role);

    /**
     * Removes the role from person.
     *
     * @param id the id
     * @param role the role
     * @return the person
     */
    @PostMapping(value = "/persons/{id}/roles", consumes = "text/uri-list")
    Person removeRoleFromPerson(@PathVariable Long id, @RequestBody String role);

    /**
     * Sets the person roles.
     *
     * @param id the id
     * @param roles the roles
     * @return the person
     */
    @PutMapping(value = "/persons/{id}/roles", consumes = "text/uri-list")
    Person setPersonRoles(@PathVariable Long id, @RequestBody String roles);
    
    /**
     * All roles.
     *
     * @return the collection model
     */
    @GetMapping(value = "/roles")
    CollectionModel<Role> allRoles();

    /**
     * Gets the role.
     *
     * @param id the id
     * @return the role
     */
    @GetMapping(value = "/roles/{id}")
    EntityModel<Role> getRole(@NonNull @PathVariable Long id);

    /**
     * Update role.
     *
     * @param id the id
     * @param access the access
     * @return the role
     */
    @PutMapping(value = "/roles/{id}")
    Role updateRole(@NonNull @PathVariable String id, @NonNull @RequestBody Role access);

    /**
     * Adds the role.
     *
     * @param access the access
     * @return the role
     */
    @PostMapping(value = "/roles/")
    Role addRole(@NonNull @RequestBody Role access);

    /**
     * Delete role.
     *
     * @param id the id
     * @return the role
     */
    @DeleteMapping(value = "/roles/{id}")
    Role deleteRole(@NonNull @PathVariable String id);

    /**
     * Gets the role accesses.
     *
     * @param id the id
     * @return the role accesses
     */
    @GetMapping(value = "/roles/{id}/allowedAccess")
    CollectionModel<Access> getRoleAccesses(@PathVariable Long id);

    /**
     * Sets the role accesses.
     *
     * @param id the id
     * @param accesses the accesses
     * @return the role
     */
    @PutMapping(value = "/roles/{id}/allowedAccess", consumes = "text/uri-list")
    Role setRoleAccesses(@PathVariable Long id, @RequestBody String accesses);

    /**
     * Adds the access to role.
     *
     * @param id the id
     * @param access the access
     * @return the person
     */
    @PostMapping(value = "/roles/{id}/allowedAccess", consumes = "text/uri-list")
    Role addAccessToRole(@PathVariable Long id, @RequestBody String access);
}
