package com.scool.web.data.service.exception;

public class AuthenticationException extends Exception {

	private static final long serialVersionUID = -6738233780674303109L;

	public AuthenticationException(String message) {
		super(message);
	}

}
