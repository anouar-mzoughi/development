package com.scool.web.ui.components;

import com.scool.web.ui.utils.FontSize;
import com.scool.web.ui.utils.FontWeight;
import com.scool.web.ui.utils.LumoStyles;
import com.scool.web.ui.utils.UIUtils;
import com.scool.web.ui.utils.css.BorderRadius;
import com.vaadin.flow.component.orderedlayout.FlexComponent;

public class Initials extends FlexBoxLayout {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7658726588234724181L;
	private String CLASS_NAME = "initials";

	public Initials(String initials) {
		setAlignItems(FlexComponent.Alignment.CENTER);
		setBackgroundColor(LumoStyles.Color.Contrast._10);
		setBorderRadius(BorderRadius.L);
		setClassName(CLASS_NAME);
		UIUtils.setFontSize(FontSize.S, this);
		UIUtils.setFontWeight(FontWeight._600, this);
		setHeight(LumoStyles.Size.M);
		setJustifyContentMode(FlexComponent.JustifyContentMode.CENTER);
		setWidth(LumoStyles.Size.M);

		add(initials);
	}

}
