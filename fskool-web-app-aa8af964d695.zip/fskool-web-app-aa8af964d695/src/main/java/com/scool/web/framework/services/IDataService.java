package com.scool.web.framework.services;

import java.util.List;

import com.scool.web.framework.data.IWithIdentifier;

/**
 * The Interface IDataService.
 *
 * @param <T> the generic type
 */
public interface IDataService<T extends IWithIdentifier> {
	
	/**
	 * Save.
	 *
	 * @param t the t
	 * @return the t
	 */
	T save(T t);

	/**
	 * Delete.
	 *
	 * @param t the t
	 * @return the t
	 */
	T delete(T t);

	/**
	 * Fetch all.
	 *
	 * @return the list
	 */
	List<T> fetchAll();
}
