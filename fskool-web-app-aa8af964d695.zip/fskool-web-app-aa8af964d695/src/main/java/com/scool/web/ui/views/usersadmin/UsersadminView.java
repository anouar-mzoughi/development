package com.scool.web.ui.views.usersadmin;

import com.scool.web.data.entity.User;
import com.scool.web.data.service.UserService;
import com.scool.web.ui.components.GridEditorView;
import com.scool.web.ui.views.main.MainView;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

@Route(value = "users-admin", layout = MainView.class)
@PageTitle("Users admin.")
public class UsersadminView extends GridEditorView<User> {

	public UsersadminView(UserService service) {
		super(User.class, service);
	}

	private static final long serialVersionUID = 7599941489233459385L;

}
