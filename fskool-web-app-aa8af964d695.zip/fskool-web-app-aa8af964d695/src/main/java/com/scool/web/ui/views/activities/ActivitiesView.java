package com.scool.web.ui.views.activities;

import com.scool.web.ui.views.main.MainView;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.router.RouteAlias;

@Route(value = "home", layout = MainView.class)
@PageTitle("Activities")
@CssImport("./styles/views/activities/activities-view.css")
@RouteAlias(value = "", layout = MainView.class)
public class ActivitiesView extends HorizontalLayout {

	private static final long serialVersionUID = -3667426562945125598L;
	private TextField name;
    private Button sayHello;

    public ActivitiesView() {
        setId("activities-view");
        name = new TextField("Your name");
        sayHello = new Button("Say hello");
        add(name, sayHello);
        setVerticalComponentAlignment(Alignment.END, name, sayHello);
        sayHello.addClickListener(e -> {
            Notification.show("Hello " + name.getValue());
        });
    }

}
