package com.scool.web.framework.services;

import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.PostMapping;

public interface IDataRemoteService<T> {

	CollectionModel<T> all();

	EntityModel<T> get(@NonNull Long id);

	T update(@NonNull String id, T access);

	@PostMapping
	T add(@NonNull T access);

	T delete(@NonNull String id);
}
