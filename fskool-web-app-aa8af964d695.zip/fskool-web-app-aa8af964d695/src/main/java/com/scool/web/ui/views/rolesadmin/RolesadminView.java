package com.scool.web.ui.views.rolesadmin;

import java.util.List;
import java.util.stream.Stream;

import com.scool.web.data.entity.Access;
import com.scool.web.data.entity.Role;
import com.scool.web.data.service.AccessService;
import com.scool.web.data.service.RoleService;
import com.scool.web.framework.data.Pair;
import com.scool.web.ui.components.GridEditorView;
import com.scool.web.ui.components.RelatedEntitiesEditor;
import com.scool.web.ui.views.main.MainView;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.data.provider.Query;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

@Route(value = "roles-admin", layout = MainView.class)
@PageTitle("Roles admin.")
public class RolesadminView extends GridEditorView<Role> {

	private static final long serialVersionUID = 3034107463142386469L;
	
	private AccessService accessesService;

	public RolesadminView(RoleService service, AccessService accessesService) {
		super(Role.class, service);
		this.accessesService = accessesService;
	}


	
	@Override
    protected List<Pair<Tab, Component>> createEditorPages(Class<Role> clazz) {
        List<Pair<Tab, Component>> pages = super.createEditorPages(clazz);
        RoleService rolesService = getRolesService();
        pages.add(Pair.newPair(new Tab("Roles"), RelatedEntitiesEditor
                .newRelatedEntitiesEditor(Role.class, Access.class).firstProvider(this::getSelection)
                .secondRetriever(rolesService::getRoleAcesses).secondFetchCallBack(this::accessesFetchCallBack)
                .secondLabelMapping(Access::getName).secondContentProvider(Access::getDescription)
                .linkHandler(rolesService::addAccessToRole).unlinkHandler(rolesService::removeAccessFromRole)
                .build()));
        return pages;
    }

	private Stream<Access> accessesFetchCallBack(Query<Access, String> q) {
		q.getLimit();
		q.getPage();
		return accessesService.fetchAll().stream();
	}

	private RoleService getRolesService() {
		return (RoleService) getDataService();
	}

}
