package com.scool.web.ui.views.accessadmin;

import com.scool.web.data.entity.Access;
import com.scool.web.data.service.AccessService;
import com.scool.web.ui.components.GridEditorView;
import com.scool.web.ui.views.main.MainView;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

@Route(value = "access-admin", layout = MainView.class)
@PageTitle("Access administration")
public class AccessAdminView extends GridEditorView<Access> {

	private static final long serialVersionUID = -6517878191381754662L;

	public AccessAdminView(AccessService service) {
		super(Access.class, service);
	}
}
