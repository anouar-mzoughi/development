package com.scool.web.ui.views.groupsadmin;

import com.scool.web.data.entity.Group;
import com.scool.web.data.service.GroupService;
import com.scool.web.ui.components.GridEditorView;
import com.scool.web.ui.views.main.MainView;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

@Route(value = "groups-admin", layout = MainView.class)
@PageTitle("Groups admin.")
public class GroupsadminView extends GridEditorView<Group> {

	private static final long serialVersionUID = 8885770328662821040L;

	public GroupsadminView( GroupService service) {
		super(Group.class, service);
	}
}
