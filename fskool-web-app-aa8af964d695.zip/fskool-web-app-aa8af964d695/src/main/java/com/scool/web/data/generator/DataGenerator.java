package com.scool.web.data.generator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;

import com.vaadin.flow.spring.annotation.SpringComponent;

@SpringComponent
public class DataGenerator {

    @Bean
    public CommandLineRunner loadData() {
        return args -> {
            Logger logger = LoggerFactory.getLogger(getClass());
//            if (roleRepository.count() != 0L) {
//                logger.info("Using existing database");
//                return;
//            }
//            int seed = 123;

            logger.info("Generating demo data");

            logger.info("... generating 100 Role entities...");
//            ExampleDataGenerator<Role> roleRepositoryGenerator = new ExampleDataGenerator<>(Role.class);
//            roleRepositoryGenerator.setData(Role::setId, DataType.ID);
//            roleRepositoryGenerator.setData(Role::setName, DataType.TWO_WORDS);
//            roleRepository.saveAll(roleRepositoryGenerator.create(100, seed));

            logger.info("... generating 100 Group entities...");
//            ExampleDataGenerator<Group> groupRepositoryGenerator = new ExampleDataGenerator<>(Group.class);
//            groupRepositoryGenerator.setData(Group::setId, DataType.ID);
//            groupRepositoryGenerator.setData(Group::setName, DataType.WORD);
//            groupRepository.saveAll(groupRepositoryGenerator.create(100, seed));

            logger.info("... generating 100 Access entities...");
//            ExampleDataGenerator<Access> accessRepositoryGenerator = new ExampleDataGenerator<>(Access.class);
//            accessRepositoryGenerator.setData(Access::setId, DataType.ID);
//            accessRepositoryGenerator.setData(Access::setName, DataType.WORD);
//            accessRepository.saveAll(accessRepositoryGenerator.create(100, seed));

            logger.info("... generating 100 User entities...");
//            ExampleDataGenerator<User> userRepositoryGenerator = new ExampleDataGenerator<>(User.class);
//            userRepositoryGenerator.setData(User::setId, DataType.ID);
//            userRepositoryGenerator.setData(User::setFirstName, DataType.FIRST_NAME);
//            userRepositoryGenerator.setData(User::setLastName, DataType.LAST_NAME);
//            userRepositoryGenerator.setData(User::setEmail, DataType.EMAIL);
//            userRepositoryGenerator.setData(User::setPhone, DataType.PHONE_NUMBER);
//            userRepositoryGenerator.setData(User::setActivated, DataType.BOOLEAN_90_10);
//            userRepository.saveAll(userRepositoryGenerator.create(100, seed));

            logger.info("Generated demo data");
        };
    }

}