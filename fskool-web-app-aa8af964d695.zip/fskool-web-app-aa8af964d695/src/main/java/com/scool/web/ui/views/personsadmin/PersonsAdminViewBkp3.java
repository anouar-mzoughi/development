package com.scool.web.ui.views.personsadmin;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;

import com.scool.web.data.entity.Person;
import com.scool.web.data.service.PersonService;
import com.scool.web.ui.utils.UIUtils;
import com.scool.web.ui.views.main.MainView;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.HasStyle;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.splitlayout.SplitLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.BeanValidationBinder;
import com.vaadin.flow.data.binder.ValidationException;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.spring.data.VaadinSpringDataHelpers;
import static java.util.Objects.nonNull;
import static java.util.Objects.isNull;

//@Route(value = "persons-admin", layout = MainView.class)
@PageTitle("Persons admin.")
@CssImport("./styles/views/personsadmin/personsadmin-view.css")
public class PersonsAdminViewBkp3 extends Div {

	private static final long serialVersionUID = 7599941489233459385L;

	private Grid<Person> grid = new Grid<>(Person.class, false);

	private TextField firstName;
	private TextField lastName;
	private TextField email;
	private TextField mobile;
	private TextField address;
	private Checkbox activated;

	private Button cancel = UIUtils.createTertiaryButton("Cancel");
	private Button save = UIUtils.createPrimaryButton("Save");
	private Button delete = UIUtils.createErrorButton("Delete"); 

	private BeanValidationBinder<Person> binder;

	private Person person;

	public PersonsAdminViewBkp3(@Autowired PersonService personsService) {
//        setId("usersadmin-view");
		// Create UI
		SplitLayout splitLayout = new SplitLayout();
		splitLayout.setSizeFull();

		createGridLayout(splitLayout);
		createEditorLayout(splitLayout);

		add(splitLayout);

		// Configure Grid
		grid.addColumn("firstName").setAutoWidth(true);
		grid.addColumn("lastName").setAutoWidth(true);
		grid.addColumn("email").setAutoWidth(true);
		grid.addColumn("mobile").setAutoWidth(true);
//        TemplateRenderer<Person> activatedRenderer = TemplateRenderer.<Person>of(
//                "<iron-icon hidden='[[!item.activated]]' icon='vaadin:check' style='width: var(--lumo-icon-size-s); height: var(--lumo-icon-size-s); color: var(--lumo-primary-text-color);'></iron-icon><iron-icon hidden='[[item.activated]]' icon='vaadin:minus' style='width: var(--lumo-icon-size-s); height: var(--lumo-icon-size-s); color: var(--lumo-disabled-text-color);'></iron-icon>")
//                .withProperty("activated", User::isActivated);
//        grid.addColumn(activatedRenderer).setHeader("Activated").setAutoWidth(true);

//		grid.setItems(query -> personsService.list(
//				PageRequest.of(query.getPage(), query.getPageSize(), VaadinSpringDataHelpers.toSpringDataSort(query)))
//				.stream());
		grid.addThemeVariants(GridVariant.LUMO_NO_BORDER);
		grid.setHeightFull();

		// when a row is selected or deselected, populate form
		grid.asSingleSelect().addValueChangeListener(event -> {
			if (event.getValue() != null) {
//				Optional<Person> userFromBackend = personsService.get(event.getValue().getIdentifier());
//				// when a row is selected but the data is no longer available, refresh grid
//				if (userFromBackend.isPresent()) {
//					populateForm(userFromBackend.get());
//				} else {
//					refreshGrid();
//				}
			} else {
				clearForm();
			}
		});

		// Configure Form
		binder = new BeanValidationBinder<>(Person.class);

		// Bind fields. This where you'd define e.g. validation rules

		binder.bindInstanceFields(this);

		cancel.addClickListener(e -> {
			clearForm();
			refreshGrid();
		});

		save.addClickListener(e -> {
			try {
				if (isNull(this.person)) {
					this.person = new Person();
				}
				binder.writeBean(this.person);

//				personsService.updateOrSaveNew(this.person);
				clearForm();
				refreshGrid();
				Notification.show("User details stored.");
			} catch (ValidationException validationException) {
				Notification.show("An exception happened while trying to store the user details.");
			}
		});
		
		delete.addClickListener(e -> {
			if (nonNull(this.person)) {
				personsService.delete(this.person);
			}

			clearForm();
			refreshGrid();
			Notification.show("User Deleted.");
		});

	}

	private void createEditorLayout(SplitLayout splitLayout) {
		Div editorLayoutDiv = new Div();
		editorLayoutDiv.setId("editor-layout");

		Div editorDiv = new Div();
		editorDiv.setId("editor");
		editorLayoutDiv.add(editorDiv);

		FormLayout formLayout = new FormLayout();
		firstName = new TextField("First Name");
		lastName = new TextField("Last Name");
		email = new TextField("Email");
		mobile = new TextField("Mobile");
		address = new TextField("Address");
		activated = new Checkbox("Activated");
		activated.getStyle().set("padding-top", "var(--lumo-space-m)");
		Component[] fields = new Component[] { firstName, lastName, email, mobile, address, activated };

		for (Component field : fields) {
			((HasStyle) field).addClassName("full-width");
		}
		formLayout.add(fields);
		editorDiv.add(formLayout);
		createButtonLayout(editorLayoutDiv);

		splitLayout.addToSecondary(editorLayoutDiv);
	}

	private void createButtonLayout(Div editorLayoutDiv) {
		HorizontalLayout buttonLayout = new HorizontalLayout();
		buttonLayout.setId("button-layout");
		buttonLayout.setWidthFull();
		buttonLayout.setSpacing(true);
		buttonLayout.add(save, cancel, delete);
		editorLayoutDiv.add(buttonLayout);
	}

	private void createGridLayout(SplitLayout splitLayout) {
		Div wrapper = new Div();
		wrapper.setId("grid-wrapper");
		wrapper.setWidthFull();
		splitLayout.addToPrimary(wrapper);
		wrapper.add(grid);
	}

	private void refreshGrid() {
		grid.select(null);
		grid.getLazyDataView().refreshAll();
	}

	private void clearForm() {
		populateForm(null);
	}

	private void populateForm(Person value) {
		this.person = value;
		binder.readBean(this.person);

	}
}
