package com.scool.web.ui.views.personsadmin;

import org.springframework.beans.factory.annotation.Autowired;

import com.scool.web.data.entity.Person;
import com.scool.web.data.service.PersonService;
import com.scool.web.ui.components.FlexBoxLayout;
import com.scool.web.ui.components.Initials;
import com.scool.web.ui.components.ListItem;
import com.scool.web.ui.layout.Horizontal;
import com.scool.web.ui.layout.Right;
import com.scool.web.ui.layout.Top;
import com.scool.web.ui.layout.Vertical;
import com.scool.web.ui.utils.LumoStyles;
import com.scool.web.ui.utils.UIUtils;
import com.scool.web.ui.utils.css.BoxSizing;
import com.scool.web.ui.views.main.MainView;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.crud.BinderCrudEditor;
import com.vaadin.flow.component.crud.Crud;
import com.vaadin.flow.component.crud.CrudEditorPosition;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.grid.ColumnTextAlign;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.Grid.SelectionMode;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexLayout;
import com.vaadin.flow.component.radiobutton.RadioButtonGroup;
import com.vaadin.flow.component.radiobutton.RadioGroupVariant;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.component.upload.Upload;
import com.vaadin.flow.data.binder.Binder;
import com.vaadin.flow.data.provider.DataProvider;
import com.vaadin.flow.data.provider.ListDataProvider;
import com.vaadin.flow.data.renderer.ComponentRenderer;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

//@Route(value = "persons-admin", layout = MainView.class)
//@PageTitle("Persons admin.")
public class PersonsAdminViewBkp2 extends Div {

	private static final long serialVersionUID = -5159211762933557634L;
	private Grid<Person> grid;
	private ListDataProvider<Person> dataProvider;

	public PersonsAdminViewBkp2(@Autowired PersonService personsService) {
//		setId("usersadmin-view");
		add(createContent(personsService));
		// filter();
	}

	private Component createContent(PersonService personsService) {
		FlexBoxLayout content = new FlexBoxLayout(createCrud(personsService));
		content.setBoxSizing(BoxSizing.BORDER_BOX);
		content.setHeightFull();
		content.setPadding(Horizontal.RESPONSIVE_X, Top.RESPONSIVE_X);
		return content;
	}

	private Crud<Person> createCrud(PersonService personsService) {
		Crud<Person> crud = new Crud<>(Person.class, createGrid(personsService), createEditor());
		UIUtils.setBackgroundColor(LumoStyles.Color.BASE_COLOR, crud);
		crud.setEditOnClick(true);
		crud.setEditorPosition(CrudEditorPosition.BOTTOM);
		crud.setSizeFull();
		return crud;
	}

	private Grid<Person> createGrid(PersonService personsService) {
		grid = new Grid<>();
		grid.setSelectionMode(SelectionMode.SINGLE);

//		dataProvider = DataProvider.ofCollection(personsService.list(null).toList());
		grid.setDataProvider(dataProvider);
		grid.setHeightFull();

		grid.addColumn(Person::getIdentifier)
				.setAutoWidth(true)
				.setFlexGrow(0)
				.setFrozen(true)
				.setHeader("ID")
				.setSortable(true);
		grid.addColumn(new ComponentRenderer<>(this::createUserInfo))
				.setAutoWidth(true)
				.setHeader("Name");
//		grid.addColumn(new ComponentRenderer<>(this::createActive))
//				.setAutoWidth(true)
//				.setFlexGrow(0)
//				.setHeader("Active")
//				.setTextAlign(ColumnTextAlign.END);
//		grid.addColumn(new ComponentRenderer<>(this::createInvoices))
//				.setAutoWidth(true)
//				.setFlexGrow(0)
//				.setHeader("Invoices")
//				.setTextAlign(ColumnTextAlign.END);
//		grid.addColumn(new ComponentRenderer<>(this::createCompanies))
//				.setAutoWidth(true)
//				.setFlexGrow(0)
//				.setHeader("Companies")
//				.setTextAlign(ColumnTextAlign.END);
//		grid.addColumn(new ComponentRenderer<>(this::createDate)).setFlexGrow(0)
//				.setAutoWidth(true)
//				.setFlexGrow(0)
//				.setHeader("Last Report")
//				.setTextAlign(ColumnTextAlign.END);

		return grid;
	}

	private Component createUserInfo(Person person) {
		ListItem item = new ListItem(
				new Initials("AB"), person.getFirstName(),
				person.getEmail());
		item.setPadding(Vertical.XS);
		item.setSpacing(Right.M);
		return item;
	}

//	private Component createActive(Person person) {
//		Icon icon;
//		if (person.isImportant()) {
//			icon = UIUtils.createPrimaryIcon(VaadinIcon.CHECK);
//		} else {
//			icon = UIUtils.createDisabledIcon(VaadinIcon.CLOSE);
//		}
//		return icon;
//	}

//	private Component createInvoices() {
//		return UIUtils.createAmountLabel(DummyData.getRandomInt(0, 5000));
//	}
//
//	private Component createCompanies() {
//		return UIUtils.createUnitsLabel(DummyData.getRandomInt(0, 50));
//	}
//
//	private Component createDate(Person person) {
//		return new Span(UIUtils.formatDate(person.getLastModified()));
//	}

	private BinderCrudEditor<Person> createEditor() {
		Binder<Person> binder = new Binder<>(Person.class);

		TextField firstName = new TextField();
		firstName.setWidthFull();
		binder.bind(firstName, "firstName");

		TextField lastName = new TextField();
		lastName.setWidthFull();
		binder.bind(lastName, "lastName");

		RadioButtonGroup<String> status = new RadioButtonGroup<>();
		status.addThemeVariants(RadioGroupVariant.LUMO_VERTICAL);
		status.setItems("Active", "Inactive");
//		binder.bind(status, 
//			(person) -> person.() ? "Active" : "Inactive", 
//			(person, value) -> person.setRandomBoolean(value == "Active" ? true : false)
//		);

//		FlexLayout phone = UIUtils.createPhoneLayout(null);

		TextField email = new TextField();
		email.setWidthFull();
		binder.bind(email, "email");

//		ComboBox<String> company = new ComboBox<>();
//		company.setItems(DummyData.getCompanies());
//		company.setValue(DummyData.getCompany());
//		company.setWidthFull();

		// Form layout
		FormLayout form = new FormLayout();
		form.addClassNames(
				LumoStyles.Padding.Bottom.L,
				LumoStyles.Padding.Horizontal.L,
				LumoStyles.Padding.Top.S
		);
		form.setResponsiveSteps(
				new FormLayout.ResponsiveStep("0", 1,
						FormLayout.ResponsiveStep.LabelsPosition.TOP),
				new FormLayout.ResponsiveStep("21em", 2,
						FormLayout.ResponsiveStep.LabelsPosition.TOP)
		);
		form.addFormItem(firstName, "First Name");
		form.addFormItem(lastName, "Last Name");
		FormLayout.FormItem statusItem = form.addFormItem(status, "Status");
//		FormLayout.FormItem phoneItem = form.addFormItem(phone, "Phone");
		FormLayout.FormItem emailItem = form.addFormItem(email, "Email");
//		FormLayout.FormItem companyItem = form.addFormItem(company, "Company");
		FormLayout.FormItem uploadItem = form.addFormItem(new Upload(), "Image");
//		UIUtils.setColSpan(2, statusItem, phoneItem, emailItem, /*companyItem,*/ uploadItem);
		return new BinderCrudEditor<>(binder, form);
	}

//	private void filter() {
//		dataProvider.setFilterByValue(Person::getRole, Person.Role.ACCOUNTANT);
//	}

}
