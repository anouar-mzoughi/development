package com.scool.web.ui.components;

import static com.google.common.base.Preconditions.checkNotNull;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;

import com.scool.web.ui.layout.Uniform;
import com.scool.web.ui.utils.LumoStyles.Margin;
import com.scool.web.ui.utils.UIUtils;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.icon.VaadinIcon;

public class EntityCard<T> extends ListItem {

    private static final long serialVersionUID = -7820515985487492421L;

    public EntityCard(T t, Function<T, String> nameMapping, Function<T, String> contentMapping,
            Consumer<T> removeHandler) {

        super(nameMapping.apply(t), contentMapping.apply(t));
         addClassName("card");
         setMargin(Uniform.XS);
         setWidthFull();
        if (Objects.nonNull(removeHandler)) {
            Button remove = UIUtils
                .createButton("Remove", VaadinIcon.TRASH, ButtonVariant.LUMO_SMALL, ButtonVariant.LUMO_ERROR);
            remove.addClickListener(e -> removeHandler.accept(t));
            remove.addClassName(Margin.Left.XS);
            setSuffix(UIUtils.createSmallButton(VaadinIcon.ELLIPSIS_DOTS_V), remove);
        }
    }

    public static <T> CardBuidler<T> newCard(T t) {
        return new CardBuidler<>(t);
    }

    public static class CardBuidler<X> {

        private X x;
        private Function<X, String> nameMapping;
        private Function<X, String> contentMapping;
        private Consumer<X> removeHandler;

        public CardBuidler(X x) {
            this.x = x;
        }

        public CardBuidler<X> nameMapping(Function<X, String> nameMapping) {
            this.nameMapping = nameMapping;
            return this;
        }

        public CardBuidler<X> contentMapping(Function<X, String> contentMapping) {
            this.contentMapping = contentMapping;
            return this;
        }

        public CardBuidler<X> removeHandler(Consumer<X> removeHandler) {
            this.removeHandler = removeHandler;
            return this;
        }

        public EntityCard<X> build() {
            return new EntityCard<X>(checkNotNull(x), checkNotNull(nameMapping), checkNotNull(contentMapping),
                    removeHandler);
        }
    }

}
