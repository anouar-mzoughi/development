package com.scool.web.data.service;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.scool.web.data.service.exception.AuthenticationException;
import com.scool.web.data.service.exception.LogoutException;
import com.scool.web.data.service.exception.RegisterException;
import com.scool.web.data.service.remote.ILoginServerRemoteService;
import com.scool.web.data.service.remote.ILoginServerRemoteService.LoginInfo;
import com.scool.web.data.service.remote.ILoginServerRemoteService.RegistrationInfo;

import joptsimple.internal.Strings;

@Service
public class AuthenticationService {

    private final ILoginServerRemoteService remoteAuthenticator;

    public AuthenticationService(ILoginServerRemoteService remoteAuthenticator) {
        this.remoteAuthenticator = remoteAuthenticator;
    }

    public String authenticate(String username, String password) throws AuthenticationException {
        try {
            ResponseEntity<?> response = remoteAuthenticator.login(new LoginInfo(username, password));
            if (response.getStatusCode() != HttpStatus.OK) {
                throw new AuthenticationException("Could not authenticate User!");
            }
            return response.getHeaders().toSingleValueMap().get("authorization");
        } catch (Exception e) {
            throw new AuthenticationException("Could not authenticate User!");
        }

    }

    public void register(String userId, String password, String code) throws RegisterException {
        String retCode = remoteAuthenticator.register(new RegistrationInfo(code, userId, password));
        if (Strings.isNullOrEmpty(retCode))
            throw new RegisterException("Service not available");
    }

    public void logout() throws LogoutException {
        // TODO Auto-generated method stub

    }

    public void activate(Long identifier) {
        ResponseEntity<?> response = remoteAuthenticator.activate(identifier);
        System.out.println(identifier + " --> " + response.toString());
    }
}
