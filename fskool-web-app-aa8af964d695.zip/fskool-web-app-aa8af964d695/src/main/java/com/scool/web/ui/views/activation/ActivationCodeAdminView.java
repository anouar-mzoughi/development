package com.scool.web.ui.views.activation;

import com.scool.web.data.entity.ActivationCode;
import com.scool.web.data.service.ActivationCodeService;
import com.scool.web.ui.components.GridEditorView;
import com.scool.web.ui.views.main.MainView;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

@Route(value = "activationcodes-admin", layout = MainView.class)
@PageTitle("Atcivation Codes")
public class ActivationCodeAdminView extends GridEditorView<ActivationCode> {

	private static final long serialVersionUID = -6266478456635095123L;

	public ActivationCodeAdminView(ActivationCodeService service) {
		super(ActivationCode.class, service);
	}

}
