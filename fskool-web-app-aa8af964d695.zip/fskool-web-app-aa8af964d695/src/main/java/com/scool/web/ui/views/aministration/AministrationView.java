package com.scool.web.ui.views.aministration;

import com.scool.web.ui.views.main.MainView;
import com.vaadin.flow.component.Text;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

@Route(value = "empty", layout = MainView.class)
@PageTitle("Aministration")
public class AministrationView extends Div {

	private static final long serialVersionUID = 8734765849969172856L;

	public AministrationView() {
        setId("aministration-view");
        add(new Text("Content placeholder"));
    }

}
