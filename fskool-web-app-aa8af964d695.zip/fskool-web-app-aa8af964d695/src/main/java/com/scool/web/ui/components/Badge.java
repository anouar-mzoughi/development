package com.scool.web.ui.components;

import java.util.StringJoiner;

import com.scool.web.ui.utils.UIUtils;
import com.scool.web.ui.utils.css.lumo.BadgeColor;
import com.scool.web.ui.utils.css.lumo.BadgeShape;
import com.scool.web.ui.utils.css.lumo.BadgeSize;
import com.vaadin.flow.component.html.Span;

/**
 * The Class Badge.
 */
public class Badge extends Span {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5577546823240218429L;

	/**
	 * Instantiates a new badge.
	 *
	 * @param text the text
	 */
	public Badge(String text) {
		this(text, BadgeColor.NORMAL);
	}

	/**
	 * Instantiates a new badge.
	 *
	 * @param text the text
	 * @param color the color
	 */
	public Badge(String text, BadgeColor color) {
		super(text);
		UIUtils.setTheme(color.getThemeName(), this);
	}

	/**
	 * Instantiates a new badge.
	 *
	 * @param text the text
	 * @param color the color
	 * @param size the size
	 * @param shape the shape
	 */
	public Badge(String text, BadgeColor color, BadgeSize size, BadgeShape shape) {
		super(text);
		StringJoiner joiner = new StringJoiner(" ");
		joiner.add(color.getThemeName());
		if (shape.equals(BadgeShape.PILL)) {
			joiner.add(shape.getThemeName());
		}
		if (size.equals(BadgeSize.S)) {
			joiner.add(size.getThemeName());
		}
		UIUtils.setTheme(joiner.toString(), this);
	}

}