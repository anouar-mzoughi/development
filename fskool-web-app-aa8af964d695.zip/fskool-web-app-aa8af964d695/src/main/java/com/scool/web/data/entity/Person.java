package com.scool.web.data.entity;

import com.google.common.base.Joiner;
import com.scool.web.framework.data.AbstractEntity;

public class Person extends AbstractEntity {

    private String firstName;
    private String lastName;
    private String email;
    private String mobile;
    private String address;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String phone) {
        this.mobile = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getInitials() {
        return (firstName.substring(0, 1) + lastName.substring(0, 1)).toUpperCase();
    }

    public String getFullName() {
        return Joiner.on(' ').join(firstName, lastName);
    }
}
