package com.scool.web.ui.utils;

public class Consts {
    public static final String AUTH_HEADER_STRING = "authorization";
    public static String SESSION_TOKEN = "TOKEN";
}
