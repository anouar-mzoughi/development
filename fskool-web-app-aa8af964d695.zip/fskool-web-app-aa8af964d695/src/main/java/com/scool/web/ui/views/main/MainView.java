package com.scool.web.ui.views.main;

import java.util.Optional;

import com.scool.web.ui.components.BrandExpression;
import com.scool.web.ui.components.NaviItem;
import com.scool.web.ui.components.NaviMenu;
import com.scool.web.ui.utils.LumoStyles;
import com.scool.web.ui.views.about.AboutView;
import com.scool.web.ui.views.accessadmin.AccessAdminView;
import com.scool.web.ui.views.activation.ActivationCodeAdminView;
import com.scool.web.ui.views.activities.ActivitiesView;
import com.scool.web.ui.views.aministration.AministrationView;
import com.scool.web.ui.views.authentication.LogoutView;
import com.scool.web.ui.views.groupsadmin.GroupsadminView;
import com.scool.web.ui.views.mypersonaldata.MyPersonalDataView;
import com.scool.web.ui.views.personsadmin.PersonsAdminView;
import com.scool.web.ui.views.rolesadmin.RolesadminView;
import com.scool.web.ui.views.usersadmin.UsersadminView;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentUtil;
import com.vaadin.flow.component.applayout.AppLayout;
import com.vaadin.flow.component.applayout.DrawerToggle;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dependency.JsModule;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.component.tabs.TabsVariant;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.PageTitle;

/**
 * The main view is a top-level placeholder for other views.
 */
@CssImport("./styles/views/main/main-view.css")
@CssImport(value = "./styles/components/grid.css", themeFor = "vaadin-grid")
@CssImport("./styles/lumo/border-radius.css")
@CssImport("./styles/lumo/icon-size.css")
@CssImport("./styles/lumo/margin.css")
@CssImport("./styles/lumo/padding.css")
@CssImport("./styles/lumo/shadow.css")
@CssImport("./styles/lumo/spacing.css")
@CssImport("./styles/lumo/typography.css")
@CssImport("./styles/misc/box-shadow-borders.css")
@CssImport(value = "./styles/styles.css", include = "lumo-badge")
@JsModule("./styles/shared-styles.js")
@JsModule("@vaadin/vaadin-lumo-styles/badge")
public class MainView extends AppLayout {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 9072743155302039220L;
	
	/** The menu. */
	private final Tabs menu;
	
	/** The view title. */
	private H1 viewTitle;

	/**
	 * Instantiates a new main view.
	 */
	public MainView() {
		setPrimarySection(Section.DRAWER);
		addToNavbar(true, createHeaderContent());
		menu = createMenu();
		addToDrawer(createDrawerContent(menu));
	}

	/**
	 * Creates the header content.
	 *
	 * @return the component
	 */
	private Component createHeaderContent() {
		HorizontalLayout layout = new HorizontalLayout();
		layout.setId("header");
		layout.getThemeList().set("dark", true);
		layout.setWidthFull();
		layout.setSpacing(false);
		layout.setAlignItems(FlexComponent.Alignment.CENTER);
		layout.add(new DrawerToggle());
		viewTitle = new H1();
		layout.add(viewTitle);
		layout.add(new Image("images/user.svg", "Avatar"));
		return layout;
	}

	/**
	 * Creates the drawer content.
	 *
	 * @param menu the menu
	 * @return the component[]
	 */
	private Component[] createDrawerContent(Tabs menu) {

		NaviMenu drawerMenu = new NaviMenu();
		drawerMenu.addNaviItem(VaadinIcon.HOME, "Activities", ActivitiesView.class);
		NaviItem adminsMenuItem = drawerMenu.addNaviItem(VaadinIcon.BOMB, "Administration", AministrationView.class);
		drawerMenu.addNaviItem(adminsMenuItem, VaadinIcon.KEY, "Activation Codes admin.",
				ActivationCodeAdminView.class);
		drawerMenu.addNaviItem(adminsMenuItem, VaadinIcon.USERS, "Users admin.", UsersadminView.class);
		drawerMenu.addNaviItem(adminsMenuItem, VaadinIcon.USER, "Persons admin.", PersonsAdminView.class);
		drawerMenu.addNaviItem(adminsMenuItem, VaadinIcon.GROUP, "Groups admin.", GroupsadminView.class);
		drawerMenu.addNaviItem(adminsMenuItem, VaadinIcon.PAINTBRUSH, "Roles admin.", RolesadminView.class);
		drawerMenu.addNaviItem(adminsMenuItem, VaadinIcon.LOCK, "Access admin.", AccessAdminView.class);

		NaviItem settingsMenuItem = drawerMenu.addNaviItem(VaadinIcon.CONTROLLER, "Settings", null);
		drawerMenu.addNaviItem(settingsMenuItem, VaadinIcon.DATABASE, "My Personal Data", MyPersonalDataView.class);
		drawerMenu.addNaviItem(settingsMenuItem, VaadinIcon.INFO, "About", AboutView.class);
		drawerMenu.addNaviItem(VaadinIcon.EXIT, "Logout", LogoutView.class);

		TextField search = new TextField();
		search.addClassName(LumoStyles.Padding.Uniform.S);
		search.addValueChangeListener(e -> drawerMenu.filter(search.getValue()));
		search.setClearButtonVisible(true);
		search.setPlaceholder("Search");
		search.setPrefixComponent(new Icon(VaadinIcon.SEARCH));

		return new Component[] { new BrandExpression("Vaadin Demo Business App"), search, drawerMenu };
	}

	/**
	 * Creates the menu.
	 *
	 * @return the tabs
	 */
	private Tabs createMenu() {
		final Tabs tabs = new Tabs();
		tabs.setOrientation(Tabs.Orientation.VERTICAL);
		tabs.addThemeVariants(TabsVariant.LUMO_MINIMAL);
		tabs.setId("tabs");
		return tabs;
	}

	/**
	 * After navigation.
	 */
	@Override
	protected void afterNavigation() {
		super.afterNavigation();
		getTabForComponent(getContent()).ifPresent(menu::setSelectedTab);
		viewTitle.setText(getCurrentPageTitle());
	}

	/**
	 * Gets the tab for component.
	 *
	 * @param component the component
	 * @return the tab for component
	 */
	private Optional<Tab> getTabForComponent(Component component) {
		return menu.getChildren().filter(tab -> ComponentUtil.getData(tab, Class.class).equals(component.getClass()))
				.findFirst().map(Tab.class::cast);
	}

	/**
	 * Gets the current page title.
	 *
	 * @return the current page title
	 */
	private String getCurrentPageTitle() {
		return getContent().getClass().getAnnotation(PageTitle.class).value();
	}
}
