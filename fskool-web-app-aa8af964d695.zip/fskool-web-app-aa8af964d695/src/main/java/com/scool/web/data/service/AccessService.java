package com.scool.web.data.service;

import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.stereotype.Service;

import com.scool.web.data.entity.Access;
import com.scool.web.data.service.remote.IDataServerRemoteService;
import com.scool.web.framework.services.DataService;
import com.scool.web.framework.services.IDataRemoteService;

@Service
public class AccessService extends DataService<Access> {

	public AccessService(IDataServerRemoteService service) {
		super(new AccessServiceProxy(service));
	}

	private static final class AccessServiceProxy implements IDataRemoteService<Access> {
		private final IDataServerRemoteService service;

		private AccessServiceProxy(IDataServerRemoteService service) {
			this.service = service;
		}

		@Override
		public CollectionModel<Access> all() {
			return service.allAcessess();
		}

		@Override
		public EntityModel<Access> get(Long id) {
			return service.getAccess(id);
		}

		@Override
		public Access update(String id, Access access) {
			return service.updateAccess(id, access);
		}

		@Override
		public Access add(Access access) {
			return service.addAccess(access);
		}

		@Override
		public Access delete(String id) {
			return service.deleteAccess(id);
		}
	}

}
