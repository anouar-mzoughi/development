package com.scool.web.ui.components;

import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import com.google.common.collect.Lists;
import com.scool.web.framework.FrameworkUtils;
import com.scool.web.framework.ISelectionListener;
import com.scool.web.framework.data.IWithIdentifier;
import com.scool.web.framework.data.Pair;
import com.scool.web.framework.services.IDataService;
import com.scool.web.ui.components.AttributesEditorForm.IFormActionsListener;
import com.scool.web.ui.layout.Horizontal;
import com.scool.web.ui.layout.Top;
import com.scool.web.ui.utils.LumoStyles;
import com.scool.web.ui.utils.UIUtils;
import com.scool.web.ui.utils.css.BoxSizing;
import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.selection.SelectionEvent;
import com.vaadin.flow.data.value.ValueChangeMode;

public abstract class GridEditorView<T extends IWithIdentifier> extends SplitViewFrame
        implements IFormActionsListener<T> {

    private static final long serialVersionUID = 6956948756805639193L;

    // UI
    private Grid<T> grid;

    // SERVICES
    private final IDataService<T> dataService;

    // LISTENERS
    private final List<ISelectionListener<T>> listeners = Lists.newArrayList();

    // OTHERS
    private final Class<T> clazz;

    private DetailsDrawer detailsDrawer;

    public GridEditorView(Class<T> clazz, IDataService<T> service) {
        dataService = service;
        this.clazz = clazz;
    }

    @Override
    protected void onAttach(AttachEvent attachEvent) {
        super.onAttach(attachEvent);
        initAppBar();
        setViewContent(createContent());
        setViewDetails(createDetailsDrawer());
        filter();
    }

    private void filter() {

    }

    private Component createDetailsDrawer() {
        detailsDrawer = createEditor(clazz);
        return detailsDrawer;
    }

    private Component createContent() {
        FlexBoxLayout content = new FlexBoxLayout(new VerticalLayout(createHeader(clazz), createGrid(clazz)));
        content.setBoxSizing(BoxSizing.BORDER_BOX);
        content.setHeightFull();
        content.setPadding(Horizontal.RESPONSIVE_X, Top.RESPONSIVE_X);
        return content;
    }

    private void initAppBar() {
        // TODO Auto-generated method stub
    }

    public IDataService<T> getDataService() {
        return dataService;
    }

    private Component createHeader(Class<T> clazz) {
        HorizontalLayout header = new HorizontalLayout(createFilterText(), createNewButton(clazz));
        header.setWidthFull();

        return header;
    }

    protected Grid<T> doCreateGrid(Class<T> clazz) {
        return new Grid<>(clazz);
    }

    private Component createNewButton(Class<T> clazz) {
        Button create = UIUtils.createPrimaryButton(VaadinIcon.PLUS);
        create.addClickListener(e -> createNewDataObject(e, clazz));
        return create;
    }

    private T instanciateDataObject(Class<T> clazz) {
        try {
            return clazz.getConstructor(new Class[] {}).newInstance(new Object[] {});
        } catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException
                | NoSuchMethodException | SecurityException e1) {
            e1.printStackTrace();
        }
        return null;
    }

    private Component createFilterText() {
        TextField textField = new TextField();
        textField.setClearButtonVisible(true);
        textField.setPlaceholder("Type To Filter");
        textField.setValueChangeMode(ValueChangeMode.EAGER);
        textField.setWidthFull();
        textField.addValueChangeListener(e -> updateList());
        return textField;
    }

    protected Optional<T> getSelection() {
        return grid.asSingleSelect().getOptionalValue();
    }

    public Object updateList() {
        grid.setItems(dataService.fetchAll());
        return null;
    }

    @SuppressWarnings("unchecked")
    private DetailsDrawer createEditor(Class<T> clazz) {

        List<Pair<Tab, Component>> pages = createEditorPages(clazz);

        Map<Tab, Component> tabsToPages = pages.stream().collect(Collectors.toMap(Pair::getFirst, Pair::getSecond));
        List<Tab> tabsList = pages.stream().map(p -> p.getFirst()).collect(Collectors.toList());
        Collection<Component> pageList = tabsToPages.values();
        pageList
            .stream()
            .filter(ISelectionListener.class::isInstance)
            .map(ISelectionListener.class::cast)
            .forEach(listeners::add);
        DetailsDrawer detailsDrawer = new DetailsDrawer();

        Tabs tabs = new Tabs();

        if (tabsList.size() >= 1) {

            tabs.add(tabsList.toArray(new Tab[tabsList.size()]));
            tabs.addSelectedChangeListener(event -> {
                Component selectedPage = tabsToPages.get(tabs.getSelectedTab());
                detailsDrawer.setContent(selectedPage);
                if (selectedPage instanceof AttributesEditorForm) {
                    detailsDrawer.setFooter(((AttributesEditorForm<T>) selectedPage).createActionsLine(clazz));
                } else {
                    detailsDrawer.setFooter();
                }
            });
            Pair<Tab, Component> fisrtPage = pages.iterator().next();
            Component first = fisrtPage.getSecond();
            tabs.setSelectedTab(fisrtPage.getFirst());
            fisrtPage.getSecond().setVisible(true);
            detailsDrawer.setContent(first);
            if (first instanceof AttributesEditorForm) {
                detailsDrawer.setFooter(((AttributesEditorForm<T>) first).createActionsLine(clazz));
            } else {
                detailsDrawer.setFooter();
            }
        }
        DetailsDrawerHeader detailsDrawerHeader = new DetailsDrawerHeader("Details", tabs);
        detailsDrawerHeader.addCloseListener(buttonClickEvent -> detailsDrawer.hide());
        detailsDrawer.setHeader(detailsDrawerHeader);
        return detailsDrawer;

    }

    @SuppressWarnings("unchecked")
    protected List<Pair<Tab, Component>> createEditorPages(Class<T> clazz) {
        return Lists.newArrayList(Pair.newPair(new Tab("Attributes"), new AttributesEditorForm<T>(clazz, this)));
    }

    private Grid<T> createGrid(Class<T> clazz) {
        grid = doCreateGrid(clazz);
        UIUtils.setBackgroundColor(LumoStyles.Color.BASE_COLOR, grid);
        grid.addSelectionListener(selection -> selectionChanged(selection, clazz));
        buildColumns(grid, clazz);
        updateList();
        return grid;
    }

    protected void buildColumns(Grid<T> grid2, Class<T> clazz2) {
        List<String> columns = FrameworkUtils.getClassPropertyNames(clazz);
        grid.setColumns(columns.toArray(new String[columns.size()]));
    }

    protected Object selectionChanged(SelectionEvent<Grid<T>, T> selection, Class<T> clazz) {
        Optional<T> firstSelectedItem = selection.getFirstSelectedItem();
        notifySelection(clazz, firstSelectedItem.orElse(null));
        return null;
    }

    protected T createNewDataObject(ClickEvent<Button> e, Class<T> clazz) {
        T instance = instanciateDataObject(clazz);
        grid.deselectAll();
        notifySelection(clazz, instance);
        detailsDrawer.show(instance);
        return instance;
    }

    private void notifySelection(Class<T> clazz, T selection) {
        listeners.forEach(l -> l.setSelection(clazz, Optional.ofNullable(selection)));
        Optional.ofNullable(selection).ifPresentOrElse(detailsDrawer::show, detailsDrawer::hide);
    }

    public Object save(Class<T> clazz, T t) {
        dataService.save(t);
        updateList();
        notifySelection(clazz, null);
        return null;
    }

    public Object delete(Class<T> clazz, T t) {
        dataService.delete(t);
        grid.select(null);
        updateList();
        notifySelection(clazz, null);
        return null;
    }

    public Object cancel(Class<T> clazz, T t) {
        notifySelection(clazz, null);
        grid.select(null);
        return null;
    }
}
