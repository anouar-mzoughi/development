package com.scool.web.framework.data;

public class Pair<T, X> {

    private final T first;
    private final X second;

    public Pair(T first, X second) {
        this.first = first;
        this.second = second;
    }

    public T getFirst() {
        return first;
    }

    public X getSecond() {
        return second;
    }

    public static final <T, X> Pair<T, X> newPair(T first, X second) {
        return new Pair<T, X>(first, second);
    }
}
