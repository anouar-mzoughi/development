package com.scool.web.data.service;

import java.util.Collections;
import java.util.List;

import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.scool.web.data.entity.Access;
import com.scool.web.data.entity.Role;
import com.scool.web.data.service.remote.IDataServerRemoteService;
import com.scool.web.framework.services.DataService;
import com.scool.web.framework.services.IDataRemoteService;

/**
 * The Class RoleService.
 */
@Service
public class RoleService extends DataService<Role> {

    /** The data service. */
    private IDataServerRemoteService dataService;

    /**
     * Instantiates a new role service.
     *
     * @param service
     *            the service
     */
    public RoleService(IDataServerRemoteService service) {
        super(new RoleServiceProxy(service));
        this.dataService = service;
    }

    /**
     * Gets the role acesses.
     *
     * @param role
     *            the role
     * @return the role acesses
     */
    public List<Access> getRoleAcesses(Role role) {
        if (role.isPersisted()) {
            return Lists.newArrayList(dataService.getRoleAccesses(role.getIdentifier()));
        } else {
            return Collections.emptyList();
        }
    }

    /**
     * Adds the access to role.
     *
     * @param role
     *            the role
     * @param access
     *            the access
     */
    public void addAccessToRole(Role role, Access access) {
        addAtoT(role, access, dataService::getRoleAccesses, dataService::getAccess, dataService::addAccessToRole);
    }

    /**
     * Removes the access from role.
     *
     * @param role
     *            the role
     * @param access
     *            the access
     */
    public void removeAccessFromRole(Role role, Access access) {
        removeAfromT(role, access, dataService::getRoleAccesses, dataService::getAccess, dataService::setRoleAccesses);
    }

    /**
     * The Class RoleServiceProxy.
     */
    private static final class RoleServiceProxy implements IDataRemoteService<Role> {

        /** The service. */
        private final IDataServerRemoteService service;

        /**
         * Instantiates a new role service proxy.
         *
         * @param service
         *            the service
         */
        public RoleServiceProxy(IDataServerRemoteService service) {
            this.service = service;
        }

        /**
         * All.
         *
         * @return the collection model
         */
        @Override
        public CollectionModel<Role> all() {
            return service.allRoles();
        }

        /**
         * Gets the.
         *
         * @param id
         *            the id
         * @return the entity model
         */
        @Override
        public EntityModel<Role> get(Long id) {
            return service.getRole(id);
        }

        /**
         * Update.
         *
         * @param id
         *            the id
         * @param access
         *            the access
         * @return the role
         */
        @Override
        public Role update(String id, Role access) {
            return service.updateRole(id, access);
        }

        /**
         * Adds the.
         *
         * @param access
         *            the access
         * @return the role
         */
        @Override
        public Role add(Role access) {
            return service.addRole(access);
        }

        /**
         * Delete.
         *
         * @param id
         *            the id
         * @return the role
         */
        @Override
        public Role delete(String id) {
            return service.deleteRole(id);
        }
    }
}
