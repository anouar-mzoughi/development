package com.scool.web.ui.components;

import static com.google.common.base.Preconditions.checkNotNull;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Supplier;

import com.scool.web.framework.ISelectionListener;
import com.scool.web.ui.utils.UIUtils;
import com.scool.web.ui.utils.css.FlexWrap;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ItemLabelGenerator;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.data.provider.CallbackDataProvider.FetchCallback;

public class RelatedEntitiesEditor<F, S> extends Div implements ISelectionListener<F> {

	private static final long serialVersionUID = -2534987854242121873L;
	private FlexBoxLayout secondList;
	private final ItemLabelGenerator<S> secondLabelMapping;
	private final FetchCallback<S, String> secondFetchCallBack;
	private final Supplier<Optional<F>> firstProvider;
	private final Function<F, List<S>> secondRetriever;
	private final Function<S, String> sContentProvider;
	private final BiConsumer<F, S> linkHandler;
	private final BiConsumer<F, S> unlinkHandler;

	public RelatedEntitiesEditor(ItemLabelGenerator<S> secondLabelMapping, FetchCallback<S, String> secondFetchCallBack,
			Supplier<Optional<F>> firstProvider, Function<F, List<S>> secondRetriever,
			Function<S, String> sContentProvider, BiConsumer<F, S> linkHandler, BiConsumer<F, S> unlinkHandler) {
		this.secondLabelMapping = secondLabelMapping;
		this.secondFetchCallBack = secondFetchCallBack;
		this.firstProvider = firstProvider;
		this.secondRetriever = secondRetriever;
		this.sContentProvider = sContentProvider;
		this.linkHandler = linkHandler;
		this.unlinkHandler = unlinkHandler;
		add(new HorizontalLayout(createRolesSection()));
	}

	private Component createRolesSection() {
		ComboBox<S> select = new ComboBox<>();
		select.setItemLabelGenerator(secondLabelMapping);
		select.setClearButtonVisible(true);
		select.setWidthFull();
		select.setItems(secondFetchCallBack);

		Button addSecondToFirst = UIUtils.createPrimaryButton(VaadinIcon.PLUS);
		addSecondToFirst.addClickListener(e -> {
			Optional<F> fOptional = firstProvider.get();
			S second = select.getValue();
			if (fOptional.isPresent() && second != null) {
				F first = fOptional.get();
				linkHandler.apply(first, second);
				refreshSeconds(secondRetriever.apply(first));
			} else {
				// TODO Notify the user
			}
		});
		secondList = new FlexBoxLayout();
		secondList.setWidthFull();
		secondList.setFlexWrap(FlexWrap.WRAP);
		HorizontalLayout header = new HorizontalLayout(new Label("Select one"), select, addSecondToFirst);
		header.setWidthFull();
		return new VerticalLayout(header, secondList);
	}

	protected void refreshSeconds(List<S> seconds) {
		secondList.removeAll();
		if (seconds != null) {
			seconds.stream().map(this::createRoleCard).forEach(secondList::add);
		}
	}

	private Component createRoleCard(S second) {
		return EntityCard.newCard(second).nameMapping(secondLabelMapping).contentMapping(sContentProvider)
				.removeHandler(this::unlinkSecond).build();
	}

	private void unlinkSecond(S s) {
		Optional<F> optional = firstProvider.get();
		if (optional.isPresent()) {
			F first = optional.get();
			unlinkHandler.apply(first, s);
			refreshSeconds(secondRetriever.apply(first));
		}
	}

	@Override
	public void setSelection(Class<F> clazz, Optional<F> selected) {
		if (selected.isPresent()) {
			refreshSeconds(secondRetriever.apply(selected.get()));
		} else {
			secondList.removeAll();
		}
	}

	@FunctionalInterface
	public static interface BiConsumer<F, S> {
		void apply(F f, S s);
	}

	public static <A, B> RelatedEntitiesEditorBuilder<A, B> newRelatedEntitiesEditor(Class<A> fClazz, Class<B> sClazz) {
		return new RelatedEntitiesEditorBuilder<>(fClazz, sClazz);
	}

	public static class RelatedEntitiesEditorBuilder<C, D> {
		private ItemLabelGenerator<D> secondLabelMapping;
		private FetchCallback<D, String> secondFetchCallBack;
		private Supplier<Optional<C>> firstProvider;
		private Function<C, List<D>> secondRetriever;
		private Function<D, String> sContentProvider;
		private BiConsumer<C, D> linkHandler;
		private BiConsumer<C, D> unlinkHandler;

		public RelatedEntitiesEditorBuilder(Class<C> fClazz, Class<D> sClazz) {
		}

		public RelatedEntitiesEditorBuilder<C, D> secondLabelMapping(ItemLabelGenerator<D> secondLabelMapping) {
			this.secondLabelMapping = secondLabelMapping;
			return this;
		}

		public RelatedEntitiesEditorBuilder<C, D> secondFetchCallBack(FetchCallback<D, String> secondFetchCallBack) {
			this.secondFetchCallBack = secondFetchCallBack;
			return this;
		}

		public RelatedEntitiesEditorBuilder<C, D> firstProvider(Supplier<Optional<C>> firstProvider) {
			this.firstProvider = firstProvider;
			return this;
		}

		public RelatedEntitiesEditorBuilder<C, D> secondRetriever(Function<C, List<D>> secondRetriever) {
			this.secondRetriever = secondRetriever;
			return this;
		}

		public RelatedEntitiesEditorBuilder<C, D> secondContentProvider(Function<D, String> sContentProvider) {
			this.sContentProvider = sContentProvider;
			return this;
		}

		public RelatedEntitiesEditorBuilder<C, D> linkHandler(BiConsumer<C, D> linkHandler) {
			this.linkHandler = linkHandler;
			return this;
		}

		public RelatedEntitiesEditorBuilder<C, D> unlinkHandler(BiConsumer<C, D> unlinkHandler) {
			this.unlinkHandler = unlinkHandler;
			return this;
		}

		public RelatedEntitiesEditor<C, D> build() {

			return new RelatedEntitiesEditor<>(checkNotNull(secondLabelMapping), checkNotNull(secondFetchCallBack),
					checkNotNull(firstProvider), checkNotNull(secondRetriever), checkNotNull(sContentProvider),
					checkNotNull(linkHandler), checkNotNull(unlinkHandler));
		}
	}
}
