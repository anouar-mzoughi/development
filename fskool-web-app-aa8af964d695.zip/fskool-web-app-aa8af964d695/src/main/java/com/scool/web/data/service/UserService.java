package com.scool.web.data.service;

import java.util.Optional;

import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.stereotype.Service;

import com.scool.web.data.entity.ActivationCode;
import com.scool.web.data.entity.User;
import com.scool.web.data.service.remote.ILoginServerRemoteService;
import com.scool.web.framework.services.DataService;
import com.scool.web.framework.services.IDataRemoteService;

/**
 * The Class UserService.
 */
@Service
public class UserService extends DataService<User> {

	/** The service. */
	private final ILoginServerRemoteService service;
	
    /**
     * Instantiates a new user service.
     *
     * @param service the service
     */
    public UserService(ILoginServerRemoteService service) {
        super(new UserServiceProxy(service));
        this.service = service;
    }
    
    /**
     * Gets the user by person id.
     *
     * @param id the id
     * @return the user by person id
     */
    public Optional<User> getUserByPersonId(Long id) {
    	return Optional.ofNullable(service.getUserByPersonId(id));
    }
    
    /**
     * Activate.
     *
     * @param personId the person id
     * @return the string
     */
    public String activate(Long personId) {
    	return service.activate(personId).getBody().getCode();
    }
    
    public Optional<ActivationCode> getCodeByPersonId(Long personId) {
    	return Optional.ofNullable(service.getActivationCodeByPersonId(personId).getBody());
    }

    /**
     * The Class UserServiceProxy.
     */
    private static final class UserServiceProxy implements IDataRemoteService<User> {
        
        /** The service. */
        private final ILoginServerRemoteService service;

        /**
         * Instantiates a new user service proxy.
         *
         * @param service the service
         */
        public UserServiceProxy(ILoginServerRemoteService service) {
            this.service = service;
        }

        /**
         * All.
         *
         * @return the collection model
         */
        @Override
        public CollectionModel<User> all() {
            return CollectionModel.of(service.allUsers());
        }

        /**
         * Gets the.
         *
         * @param id the id
         * @return the entity model
         */
        @Override
        public EntityModel<User> get(Long id) {
            return EntityModel.of(service.getUser(id));
        }

        /**
         * Update.
         *
         * @param id the id
         * @param access the access
         * @return the user
         */
        @Override
        public User update(String id, User access) {
            return service.updateUser(id, access);
        }

        /**
         * Adds the.
         *
         * @param access the access
         * @return the user
         */
        @Override
        public User add(User access) {
            return service.addUser(access);
        }

        /**
         * Delete.
         *
         * @param id the id
         * @return the user
         */
        @Override
        public User delete(String id) {
            return service.deleteUser(id);
        }
    }
}
