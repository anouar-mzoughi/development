package com.scool.web.data.service;

import java.util.Collections;
import java.util.List;

import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.scool.web.data.entity.Person;
import com.scool.web.data.entity.Role;
import com.scool.web.data.service.remote.IDataServerRemoteService;
import com.scool.web.framework.services.DataService;
import com.scool.web.framework.services.IDataRemoteService;

/**
 * The Class PersonService.
 */
@Service
public class PersonService extends DataService<Person> {

    /** The data service. */
    private IDataServerRemoteService dataService;

    @Override
    public List<Person> fetchAll() {
        List<Person> fetchAll = super.fetchAll();
        return fetchAll;
    }

    /**
     * Instantiates a new person service.
     *
     * @param service
     *            the service
     */
    public PersonService(IDataServerRemoteService service) {
        super(new PersonServiceProxy(service));
        this.dataService = service;
    }

    /**
     * Gets the person roles.
     *
     * @param person
     *            the person
     * @return the person roles
     */
    public List<Role> getPersonRoles(Person person) {
        if (person.isPersisted()) {
            return Lists.newArrayList(dataService.getPersonRoles(person.getIdentifier()));
        } else {
            return Collections.emptyList();
        }
    }

    /**
     * Adds the role to person.
     *
     * @param person
     *            the person
     * @param role
     *            the role
     */
    public void addRoleToPerson(Person person, Role role) {
        addAtoT(person, role, dataService::getPersonRoles, dataService::getRole, dataService::addRoleToPerson);
    }

    /**
     * Removes the role from person.
     *
     * @param person
     *            the person
     * @param role
     *            the role
     */
    public void removeRoleFromPerson(Person person, Role role) {
        removeAfromT(person, role, dataService::getPersonRoles, dataService::getRole, dataService::setPersonRoles);
    }

    /**
     * The Class PersonServiceProxy.
     */
    private static final class PersonServiceProxy implements IDataRemoteService<Person> {

        /** The service. */
        private final IDataServerRemoteService service;

        /**
         * Instantiates a new person service proxy.
         *
         * @param service
         *            the service
         */
        public PersonServiceProxy(IDataServerRemoteService service) {
            this.service = service;
        }

        /**
         * All.
         *
         * @return the collection model
         */
        @Override
        public CollectionModel<Person> all() {
            return service.allPersons();
        }

        /**
         * Gets the.
         *
         * @param id
         *            the id
         * @return the entity model
         */
        @Override
        public EntityModel<Person> get(Long id) {
            return service.getPerson(id);
        }

        /**
         * Update.
         *
         * @param id
         *            the id
         * @param access
         *            the access
         * @return the person
         */
        @Override
        public Person update(String id, Person access) {
            return service.updatePerson(id, access);
        }

        /**
         * Adds the.
         *
         * @param access
         *            the access
         * @return the person
         */
        @Override
        public Person add(Person access) {
            return service.addPerson(access);
        }

        /**
         * Delete.
         *
         * @param id
         *            the id
         * @return the person
         */
        @Override
        public Person delete(String id) {
            return service.deletePerson(id);
        }
    }
}
