package com.scool.web.framework.data;

import javax.persistence.MappedSuperclass;

/**
 * The Class AbstractEntity.
 */
@MappedSuperclass
public abstract class AbstractEntity implements IWithIdentifier {

    /** The identifier. */
    private Long identifier;
    
    public AbstractEntity() {
        // 
    }

    /**
     * Instantiates a new abstract entity.
     *
     * @param id the id
     */
    public AbstractEntity(Long id) {
        identifier = id;
    }

    /**
     * Gets the identifier.
     *
     * @return the identifier
     */
    public Long getIdentifier() {
        return identifier;
    }

    /**
     * Sets the identifier.
     *
     * @param id
     *            the new identifier
     */
    public void setIdentifier(Long id) {
        this.identifier = id;
    }

    /**
     * Hash code.
     *
     * @return the int
     */
    @Override
    public int hashCode() {
        if (identifier != null) {
            return identifier.hashCode();
        }
        return super.hashCode();
    }

    /**
     * Equals.
     *
     * @param obj
     *            the obj
     * @return true, if successful
     */
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof AbstractEntity)) {
            return false; // null or other class
        }
        AbstractEntity other = (AbstractEntity) obj;

        if (isPersisted()) {
            return identifier.equals(other.identifier);
        }
        return super.equals(other);
    }

}