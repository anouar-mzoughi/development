package com.scool.web.data.service.exception;

public class RegisterException extends Exception {

	private static final long serialVersionUID = 2201543558085742430L;

	public RegisterException(String message) {
		super(message);
	}
	
	

}
