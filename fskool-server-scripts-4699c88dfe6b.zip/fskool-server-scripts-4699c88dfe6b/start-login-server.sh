java -jar -Xmx1024M -Xms512M login-server-0.0.1-SNAPSHOT.jar -Dspring.datasource.url=jdbc:h2:file:/home/fskool/tui/usersdb >> log.txt

