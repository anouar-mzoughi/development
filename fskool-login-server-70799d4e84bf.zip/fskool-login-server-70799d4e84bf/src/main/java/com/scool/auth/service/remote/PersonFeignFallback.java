package com.scool.auth.service.remote;

import java.util.Collections;
import java.util.List;

import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.stereotype.Component;

import com.scool.auth.service.remote.data.Person;

@Component
public class PersonFeignFallback implements PersonService {

    @Override
    public CollectionModel<Person> findAll() {
        return new CollectionModel<>(Collections.emptyList());
    }

    @Override
    public EntityModel<Person> findById(Long id) {
        return null;
    }

	@Override
	public Person save(Person person) {
		System.out.print("Save transaction failed!");
		return null;
	}

	@Override
	public List<Person> findBySmartCode(String smartCode) {
		System.out.print("Failed to retrieve person by smart code");
		return null;
	}
}
