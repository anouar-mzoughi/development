package com.scool.auth.service.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.scool.auth.service.model.ActivationCode;
import com.scool.auth.service.model.CodeWithId;

@RepositoryRestResource(excerptProjection = CodeWithId.class)
public interface ActivationCodeRepository extends CrudRepository<ActivationCode, Long> {
	
	Optional<ActivationCode> findByCode(String code);
	
	List<ActivationCode> findByPersonId(Long personId);
	
}
