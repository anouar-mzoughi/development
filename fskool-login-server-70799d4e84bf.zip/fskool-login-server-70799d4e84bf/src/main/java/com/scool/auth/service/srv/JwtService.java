package com.scool.auth.service.srv;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.scool.auth.service.jwt.JwtAuthentication;
import com.scool.auth.service.jwt.JwtToken;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;

@Service
public class JwtService {

	private final String signingKey;

	@Autowired
	public JwtService(@Value("${security.jwt.signing-key}") String signingKey) {
		this.signingKey = signingKey;
	}

	public ResponseEntity<Object> parseJwt(JwtToken jwtToken) {
		Objects.requireNonNull(jwtToken);

		try {
			Claims claims = Jwts.parser().setSigningKey(signingKey.getBytes()).parseClaimsJws(jwtToken.getToken()).getBody();

			String username = claims.getSubject();
			String password = claims.get("password", String.class);
			List<String> authorities = claims.get("authorities", List.class);

			return new ResponseEntity<>(new JwtAuthentication(username, password, authorities), HttpStatus.OK);

		} catch (Exception ex) {
			return new ResponseEntity<>(ex.getLocalizedMessage(), HttpStatus.BAD_REQUEST);
		}
	}
}
