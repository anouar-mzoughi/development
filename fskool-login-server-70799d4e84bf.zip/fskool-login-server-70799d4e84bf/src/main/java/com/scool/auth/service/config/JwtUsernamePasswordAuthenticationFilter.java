package com.scool.auth.service.config;

import java.io.IOException;
import java.time.Instant;
import java.util.Date;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.bouncycastle.util.Objects;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.scool.auth.service.model.DataUser;
import com.scool.auth.service.srv.DataUserService;

import io.jsonwebtoken.Jwts;

public class JwtUsernamePasswordAuthenticationFilter extends AbstractAuthenticationProcessingFilter {

	private final String signingKey;

	private DataUserService dataUserService;

	private DataUser issuer;

	public JwtUsernamePasswordAuthenticationFilter(AuthenticationManager authenticationManager, String signingKey,
			DataUserService dataUserService) {
		super(new AntPathRequestMatcher("/auth/login", "POST"));
		setAuthenticationManager(authenticationManager);
		this.signingKey = signingKey;
		this.dataUserService = dataUserService;
	}

	@Override
	public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response)
			throws AuthenticationException, IOException {

		issuer = new ObjectMapper().readValue(request.getInputStream(), DataUser.class);

		Optional<DataUser> creds;
		String username, password;
		/*
		 * if(!issuer.getActivationCode().isEmpty()) { creds =
		 * dataUserService.findByActivationCode(issuer.getActivationCode());
		 * 
		 * }else if(!issuer.getUsername().isEmpty()){
		 */
		creds = dataUserService.findByUsername(issuer.getUsername());
		/*
		 * }else { throw new
		 * BadCredentialsException("Wrong given credentials data, please try again."); }
		 */
		if (!creds.isPresent()) {
			throw new BadCredentialsException("Wrong given credentials data, please try again.");
		}
		username = creds.get().getUsername();
		password = creds.get().getPassword();
		if (!Objects.areEqual(creds.get().getPassword(), issuer.getPassword())) {
			throw new BadCredentialsException("Wrong given password, please try again.");
		}

		/*
		 * To use Authentication manager we have to create Authentification provider
		 * with UserDetailsService and DataUser extend UserDetails return
		 * this.authenticationManager.authenticate( new
		 * UsernamePasswordAuthenticationToken( creds.get().getUsername(),
		 * creds.get().getPassword()) );
		 */
		return new UsernamePasswordAuthenticationToken(username, password);
	}

	@Override
	protected void successfulAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain chain,
			Authentication auth) {
	    String token = JWT.create()
	            .withSubject(auth.getName())
	            .withExpiresAt(new Date(System.currentTimeMillis() + SecurityConstants.EXPIRATION_TIME))
	            .sign(Algorithm.HMAC512(SecurityConstants.SECRET.getBytes()));
		response.addHeader(SecurityConstants.HEADER_STRING, SecurityConstants.TOKEN_PREFIX + " " + token);
	}

	@Override
	protected void unsuccessfulAuthentication(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException failed) throws IOException, ServletException {

		System.out.print("Authentication request failed: " + failed.toString());

		super.unsuccessfulAuthentication(request, response, failed);

	}
}
