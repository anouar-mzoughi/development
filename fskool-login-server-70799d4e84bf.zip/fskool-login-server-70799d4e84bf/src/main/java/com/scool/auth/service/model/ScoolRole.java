package com.scool.auth.service.model;

public enum ScoolRole {
    PERSON,
	USER,
	STUDENT,
	PARENT,
	TEACHER,
	ADMIN,
	MANAGER
}
