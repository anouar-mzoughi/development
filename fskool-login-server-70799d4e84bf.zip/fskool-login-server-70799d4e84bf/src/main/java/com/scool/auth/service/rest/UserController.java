package com.scool.auth.service.rest;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.scool.auth.service.model.DataUser;
import com.scool.auth.service.srv.DataUserService;

@RestController
@RequestMapping("/auth")
public class UserController {

	@Autowired
	DataUserService userService;

	@PostMapping("/users")
	public ResponseEntity<Object> add(@RequestBody DataUser user) {
		return new ResponseEntity<>(userService.save(user), HttpStatus.CREATED);
	}

	@RequestMapping(value = "/users/{id}")
	public ResponseEntity<Object> findById(@PathVariable("id") Long id) {
		Optional<DataUser> user = userService.findById(id);
		if (user.isEmpty()) {
			new ResponseEntity<>(String.format("User with id: %s was not found.", id), HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(user.get(), HttpStatus.OK);
	}

	@RequestMapping(value = "/users/{username}")
	public ResponseEntity<Object> findByUserName(@PathVariable("username") String username) {
		Optional<DataUser> user = userService.findByUsername(username);
		if (user.isPresent()) {
			new ResponseEntity<>(String.format("User with username: %s was not found.", username),
					HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(user.get(), HttpStatus.OK);
	}

	@GetMapping(value = "/users/byPersonId/{id}")
	public ResponseEntity<Object> findByUserName(@PathVariable("id") Long id) {
		Optional<DataUser> user = userService.findByPersonId(id);
		if (user.isPresent()) {
			return new ResponseEntity<>(user.get(), HttpStatus.OK);
		}
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@RequestMapping(value = "/users")
	public ResponseEntity<Object> findAll() {
		return new ResponseEntity<>(userService.findAll(), HttpStatus.OK);
	}

	@PutMapping(value = "/users")
	public ResponseEntity<Object> update(@RequestBody DataUser entity) {
		Optional<DataUser> user = userService.findByUsername(entity.getUsername());
		if (!user.isPresent()) {
			return new ResponseEntity<>(String.format("User with username: %s was not found.", entity.getUsername()),
					HttpStatus.BAD_REQUEST);
		}
		user.get().setUsername(entity.getUsername());
		user.get().setPassword(entity.getPassword());

		return new ResponseEntity<>(userService.update(user.get()), HttpStatus.OK);
	}

	@DeleteMapping(value = "/users/{id}")
	public ResponseEntity<Object> delete(@PathVariable("id") Long id) {
		Optional<DataUser> user = userService.findById(id);
		if (!user.isPresent()) {
			return new ResponseEntity<>(String.format("User with 'id' %s was not found.", id), HttpStatus.BAD_REQUEST);
		}
		userService.delete(user.get());
		return new ResponseEntity<>("User deleted successfully", HttpStatus.OK);
	}
}
