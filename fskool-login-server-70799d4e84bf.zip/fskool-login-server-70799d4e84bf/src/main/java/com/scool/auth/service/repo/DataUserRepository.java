package com.scool.auth.service.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.scool.auth.service.model.DataUser;
import com.scool.auth.service.model.UserWithId;

@RepositoryRestResource(excerptProjection = UserWithId.class)
public interface DataUserRepository extends JpaRepository<DataUser, Long> {

	List<DataUser> findAllByUsername(String username);

	Optional<DataUser> findByUsername(String username);
	List<DataUser> findByPersonId(Long personId);
	

}
