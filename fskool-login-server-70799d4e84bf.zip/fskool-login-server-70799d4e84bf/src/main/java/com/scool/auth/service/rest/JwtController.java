package com.scool.auth.service.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.scool.auth.service.jwt.JwtToken;
import com.scool.auth.service.srv.JwtService;

@RestController
@RequestMapping("/auth")
public class JwtController {

    private final Logger log = LoggerFactory.getLogger(JwtController.class);

    final JwtService jwtService;

    public JwtController(JwtService jwtService) {
        this.jwtService = jwtService;
    }

    /**
     * Validate and parse JWT
     */
    @RequestMapping(value = "/jwt", method = RequestMethod.POST)
    public ResponseEntity<Object> parseJwt(@RequestBody JwtToken jwtRequest) {
        try {
            return jwtService.parseJwt(jwtRequest);

        } catch (Exception ex) {
            log.error("JWT parsing error: {}, token: {}", ex.getLocalizedMessage(), jwtRequest);
            ex.printStackTrace();

            return new ResponseEntity<>(ex.getLocalizedMessage(), HttpStatus.UNAUTHORIZED);
        }
    }
}
