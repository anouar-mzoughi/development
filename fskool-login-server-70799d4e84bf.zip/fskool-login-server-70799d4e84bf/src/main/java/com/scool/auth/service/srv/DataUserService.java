package com.scool.auth.service.srv;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scool.auth.service.model.DataUser;
import com.scool.auth.service.remote.PersonService;
import com.scool.auth.service.repo.DataUserRepository;

@Service
public class DataUserService {

	@Autowired
	private DataUserRepository repo;

	@Autowired
	PersonService personService;

	public DataUserService(DataUserRepository repo) {
		super();
		this.repo = repo;
	}

	public Optional<DataUser> findById(Long id) {
		return repo.findById(id);
	}

	public List<DataUser> findAll() {
		return repo.findAll();
	}

	public Optional<DataUser> save(DataUser user) {
		return Optional.of(repo.save(user));
	}

	public Optional<DataUser> update(DataUser entity) {
		return this.save(entity);
	}

	public void delete(DataUser entity) {
		repo.delete(entity);

	}

	public Optional<DataUser> findByUsername(String username) {
		return repo.findAllByUsername(username).stream().findFirst();
	}
	
	public Optional<DataUser> findByPersonId(Long personid) {
		return repo.findByPersonId(personid).stream().findFirst();
	}
}
