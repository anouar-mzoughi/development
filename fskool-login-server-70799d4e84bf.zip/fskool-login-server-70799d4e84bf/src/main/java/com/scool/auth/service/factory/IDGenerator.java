package com.scool.auth.service.factory;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;

import javax.management.RuntimeErrorException;

import org.apache.logging.log4j.util.Strings;
import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.IdentifierGenerator;

public class IDGenerator implements IdentifierGenerator {

	public IDGenerator() {

	}

	@Override
	public Serializable generate(SharedSessionContractImplementor session, Object object) throws HibernateException {

		return IDGenerator.generate();
	}

	public static String generate() {

		int leftLimit = 48; // numeral '0'
		int rightLimit = 122; // letter 'z'
		int targetStringLength = 10;
		Random random = new Random();
		String generatedId = Strings.EMPTY;
		boolean notGen = true;

		generatedId = random.ints(leftLimit, rightLimit + 1).filter(i -> (i <= 57 || i >= 65) && (i <= 90 || i >= 97))
				.limit(targetStringLength)
				.collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append).toString();

		if (generatedId.isEmpty()) {
			throw new RuntimeErrorException(new Error("Empty ID generated"));
		}
		
		return generatedId;
	}

	boolean isExist(SharedSessionContractImplementor session) {
		Connection connection = session.connection();
		try {
			Statement statement = connection.createStatement();

			ResultSet rs = statement.executeQuery("select activationCode from DataUser");

			return rs.isFirst();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
}