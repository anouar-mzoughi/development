package com.scool.auth.service.model;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.rest.core.config.Projection;

@Projection(name = "withId", types = { DataUser.class })
public interface UserWithId {
	
	@Value("#{target.id}")
	Long getIdentifier();
	
	String getUsername();
}
