package com.scool.auth.service.rest;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.scool.auth.service.model.ActivationCode;
import com.scool.auth.service.model.DataUser;
import com.scool.auth.service.remote.PersonService;
import com.scool.auth.service.remote.data.Person;
import com.scool.auth.service.repo.ActivationCodeRepository;
import com.scool.auth.service.srv.DataUserService;

@RestController
@RequestMapping("/auth")
public class AccessController {

	@Autowired
	DataUserService userService;
	@Autowired
	ActivationCodeRepository codeRepository;
	@Autowired
	PersonService personService;

	@PostMapping("/register")
	public ResponseEntity<Object> register(@RequestBody RegistrationInfo regInfo) {

		if (userService.findByUsername(regInfo.getUsername()).isPresent()) {
			return new ResponseEntity<>("Username already used, please choose another username.", HttpStatus.BAD_REQUEST);
		}

		if (regInfo.getActivationCode() == null || regInfo.getUsername() == null || regInfo.getPassword() == null
				|| regInfo.getActivationCode().isEmpty() || regInfo.getUsername().isEmpty()
				|| regInfo.getPassword().isEmpty()) {
			return new ResponseEntity<>("Activation code or credentials was not given.", HttpStatus.BAD_REQUEST);
		}
		Optional<ActivationCode> foundCode = codeRepository.findByCode(regInfo.getActivationCode());
		if (!foundCode.isPresent()) {
			return new ResponseEntity<>(
					String.format("User with given Activation code: %s doesn't exit.", regInfo.getActivationCode()),
					HttpStatus.BAD_REQUEST);
		}
		ActivationCode activationCode = foundCode.get();

		Person person = personService.findById(activationCode.getPersonId()).getContent();// (activationCode.getCode());
		if (person == null) {
			return new ResponseEntity<>("User is not yet created, please contact Administrator.", HttpStatus.BAD_REQUEST);
		}

		Optional<DataUser> newUser = userService.save(new DataUser(regInfo.getUsername(), regInfo.getPassword(),
				activationCode.getPersonId(), "", ""));

		if (newUser.isPresent()) {
			codeRepository.delete(activationCode);
		}
		return new ResponseEntity<>(newUser, HttpStatus.CREATED);
	}

	
	@GetMapping("/activate/{id}")
	public ResponseEntity<Object> activatePerson(@PathVariable("id") Long id) {
		Person person = personService.findById(id).getContent();
		if (person == null) {
			return new ResponseEntity<>(String.format("User with id '%s' was not found, activation failed", id),
					HttpStatus.NOT_FOUND);
		}

		List<ActivationCode> codes = codeRepository.findByPersonId(id);
		if (!codes.isEmpty()) {
			return new ResponseEntity<>(codes.iterator().next(), HttpStatus.OK);// return ok if existing code
		}

		ActivationCode code = new ActivationCode(id);
		codeRepository.save(code);

		return new ResponseEntity<>(code, HttpStatus.CREATED);// return status created of new code
	}
	
	@GetMapping("/activationCodes/byPersonId/{id}")
	public ResponseEntity<ActivationCode> getActivationCodeByPersonId(@PathVariable Long id) {
		List<ActivationCode> code = codeRepository.findByPersonId(id);
		if(code.isEmpty()) {
			 return new ResponseEntity<>(HttpStatus.OK);
		}
		return  new ResponseEntity<>(code.iterator().next(),HttpStatus.OK);
	}

	public static class RegistrationInfo {

		private String activationCode;
		private String username;
		private String password;

		public RegistrationInfo(String activationCode, String username, String password) {
			this.activationCode = activationCode;
			this.username = username;
			this.password = password;
		}

		public String getActivationCode() {
			return activationCode;
		}

		public String getUsername() {
			return username;
		}

		public String getPassword() {
			return password;
		}

	}
}
