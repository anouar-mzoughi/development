package com.scool.auth.service.remote.data;

import java.sql.Date;

public class Person {

    private Long identifier;
    private String firstName = "";
    private String lastName = "";
    private String email = "";
    private String mobile = "";
    private String address = "";

    public Person() {

    }

    public Person(Long id, String firstName, String lastName, Date birthday, String email,
            String mobile, String address) {
        super();
        identifier = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.mobile = mobile;
        this.address = address;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Long getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Long id) {
        this.identifier = id;
    }
}
