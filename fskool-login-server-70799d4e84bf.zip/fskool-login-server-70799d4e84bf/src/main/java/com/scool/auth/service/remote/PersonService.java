package com.scool.auth.service.remote;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.scool.auth.service.remote.data.Person;

@FeignClient("data-server") // configuration = ClientConfiguration.class, fallback = PersonFeignFallback.class)
public interface PersonService {

    @GetMapping(value = "/persons")
    CollectionModel<Person> findAll();

    @GetMapping(value = "/persons/{id}")
    EntityModel<Person> findById(@NonNull @PathVariable Long id);

    @GetMapping(value = "/persons/smartCode/{smartCode}")
    List<Person> findBySmartCode(@PathVariable String smartCode);

    @PostMapping(value = "/persons")
    Person save(@NonNull @RequestBody Person person);
}
