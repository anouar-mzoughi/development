package com.scool.auth.service.model;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.rest.core.config.Projection;

/**
 * The Interface CodeWithId.
 */
@Projection(name = "withId", types = { ActivationCode.class })
public interface CodeWithId {

	/**
	 * Gets the identifier.
	 *
	 * @return the identifier
	 */
	@Value("#{target.id}")
	Long getIdentifier();

	/**
	 * Gets the code.
	 *
	 * @return the code
	 */
	String getCode();

	/**
	 * Gets the person id.
	 *
	 * @return the person id
	 */
	Long getPersonId();
}
