package com.scool.auth.service.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.scool.auth.service.factory.IDGenerator;

@Entity
public class ActivationCode {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	private String code = IDGenerator.generate();

	private Long personId;

	public ActivationCode() {
		//
	}
	
	public ActivationCode(Long personId) {
		this.personId = personId;
	}
	
	public ActivationCode(String code) {
		this.code = code;
	}

	public ActivationCode(Long id, String code, Long person) {
		this.id = id;
		this.code = code;
		this.personId = person;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Long getPersonId() {
		return personId;
	}

	public void setPersonId(Long person) {
		this.personId = person;
	}

}
