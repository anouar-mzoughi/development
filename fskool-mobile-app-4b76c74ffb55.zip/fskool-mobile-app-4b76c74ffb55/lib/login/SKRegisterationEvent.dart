
import 'package:meta/meta.dart';
import 'package:equatable/equatable.dart';

abstract class SKRegistrationEvent extends Equatable {
  SKRegistrationEvent([List props = const []]) : super(props);
}

class SKRegistrationStarted extends SKRegistrationEvent {
  @override
  String toString() => 'registration Started';
}

class SKRegistrationPerformed extends SKRegistrationEvent {
  final String token;

  SKRegistrationPerformed({@required this.token}) : super([token]);

  @override
  String toString() => 'LoggedIn { token: $token }';
}