// Copyright (c) 2020, the FSCool project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// license that can be found in the LICENSE file.


import 'package:equatable/equatable.dart';

abstract class SKAuthenticationState extends Equatable {
  @override
  List<Object> get props => [];
}

class SKAuthenticationUninitialized extends SKAuthenticationState {}

class SKAuthenticationAuthenticated extends SKAuthenticationState {}

class SKAuthenticationUnauthenticated extends SKAuthenticationState {}

class SKAuthenticationLoading extends SKAuthenticationState {}