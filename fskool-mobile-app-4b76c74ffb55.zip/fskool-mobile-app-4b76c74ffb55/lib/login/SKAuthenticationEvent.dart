// Copyright (c) 2020, the FSCool project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// license that can be found in the LICENSE file.


import 'package:meta/meta.dart';
import 'package:equatable/equatable.dart';

abstract class SKAuthenticationEvent extends Equatable {
  SKAuthenticationEvent([List props = const []]) : super(props);
}

class SKAppStarted extends SKAuthenticationEvent {
  @override
  String toString() => 'AppStarted';
}

class SKLoggedIn extends SKAuthenticationEvent {
  final String token;

  SKLoggedIn({@required this.token}) : super([token]);

  @override
  String toString() => 'LoggedIn { token: $token }';
}

class SKLoggedOut extends SKAuthenticationEvent {
  @override
  String toString() => 'LoggedOut';
}