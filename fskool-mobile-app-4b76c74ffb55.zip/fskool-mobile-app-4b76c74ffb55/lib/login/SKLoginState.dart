// Copyright (c) 2020, the FSCool project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// license that can be found in the LICENSE file.


import 'package:meta/meta.dart';
import 'package:equatable/equatable.dart';

abstract class SKLoginState extends Equatable {
  @override
  List<Object> get props => [];
}

class SKLoginInitial extends SKLoginState {}

class SKLoginLoading extends SKLoginState {}

class SKLoginFailure extends SKLoginState {
  final String error;
  SKLoginFailure({@required this.error});

  @override
  List<Object> get props => [error];

  @override
  String toString() => 'LoginFailure { error: $error }';
}