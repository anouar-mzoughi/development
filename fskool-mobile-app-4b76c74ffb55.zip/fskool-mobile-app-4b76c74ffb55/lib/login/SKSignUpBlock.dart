import 'dart:async';

import 'package:meta/meta.dart';
import 'package:bloc/bloc.dart';
import 'package:skool/login/SKLoginBloc.dart';

import 'SKAuthenticationBloc.dart';
import 'SKAuthenticationEvent.dart';
import 'SKLoginEvent.dart';
import 'SKLoginState.dart';
import 'SKSignUpEvent.dart';
import 'SKSignUpState.dart';
import 'SKUserRepository.dart';

class SKSignUpBloc extends Bloc<SKSignUpEvent, SKSignUpState> {
  final SKUserRepository userRepository;

  SKSignUpBloc({
    @required this.userRepository,
    //@required this.authenticationBloc,
  }) : assert(userRepository != null
            // ,assert(authenticationBloc != null)
            );

  @override
  SKSignUpState get initialState => SKSignUpInitial();

  @override
  Stream<SKSignUpState> mapEventToState(
    SKSignUpEvent event,
  ) async* {
    if (event is SKSignUpButtonPressed) {
      yield SKSignUpLoading();

      try {
        await userRepository.registerUser(
          username: event.username,
          password: event.password,
        );
        yield SKSignUpSuccessFul();
      } catch (error) {
        yield SKSignUpFailure(error: error.toString());
      }
    }
  }
}
