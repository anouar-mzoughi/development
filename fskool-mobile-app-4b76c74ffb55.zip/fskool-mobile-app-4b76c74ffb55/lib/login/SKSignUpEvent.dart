

import 'package:meta/meta.dart';
import 'package:equatable/equatable.dart';

abstract class SKSignUpEvent extends Equatable {
}

class SKSignUpButtonPressed extends SKSignUpEvent {
  final String username;
  final String password;

  SKSignUpButtonPressed({
    @required this.username,
    @required this.password,
  });

  @override
  List<Object> get props => [username, password];

  @override
  String toString() =>
      'LoginButtonPressed { username: $username, password: $password }';
}