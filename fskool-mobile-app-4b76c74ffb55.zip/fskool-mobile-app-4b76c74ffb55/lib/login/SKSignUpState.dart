import 'package:meta/meta.dart';
import 'package:equatable/equatable.dart';

abstract class SKSignUpState extends Equatable {
  @override
  List<Object> get props => [];
}

class SKSignUpInitial extends SKSignUpState {}

class SKSignUpLoading extends SKSignUpState {}
class SKSignUpSuccessFul extends SKSignUpState {}

class SKSignUpFailure extends SKSignUpState {
  final String error;
  SKSignUpFailure({@required this.error});

  @override
  List<Object> get props => [error];

  @override
  String toString() => 'Sign Up Failure { error: $error }';
}