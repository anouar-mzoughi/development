// Copyright (c) 2020, the FSCool project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// license that can be found in the LICENSE file.


import 'dart:async';

import 'package:meta/meta.dart';
import 'package:bloc/bloc.dart';

import 'SKAuthenticationEvent.dart';
import 'SKAuthenticationState.dart';
import 'SKUserRepository.dart';

class SKAuthenticationBloc
    extends Bloc<SKAuthenticationEvent, SKAuthenticationState> {
  final SKUserRepository userRepository;

  SKAuthenticationBloc({@required this.userRepository})
      : assert(userRepository != null);

  @override
  SKAuthenticationState get initialState => SKAuthenticationUninitialized();

  @override
  Stream<SKAuthenticationState> mapEventToState(
    SKAuthenticationEvent event,
  ) async* {
    if (event is SKAppStarted) {
      final bool hasToken = await userRepository.hasToken();

      if (hasToken) {
        yield SKAuthenticationAuthenticated();
      } else {
        yield SKAuthenticationUnauthenticated();
      }
    }

    if (event is SKLoggedIn) {
      yield SKAuthenticationLoading();
      await userRepository.persistToken(event.token);
      yield SKAuthenticationAuthenticated();
    }

    if (event is SKLoggedOut) {
      yield SKAuthenticationLoading();
      await userRepository.deleteToken();
      yield SKAuthenticationUnauthenticated();
    }
  }
}
