
import 'package:equatable/equatable.dart';

abstract class SKRegistrationState extends Equatable {
  @override
  List<Object> get props => [];
}

class SKRegistrationUninitialized extends SKRegistrationState {}

class SKRegistered extends SKRegistrationState {}

class SKNonRegistered extends SKRegistrationState {}

class SKRegisteringLoading extends SKRegistrationState {}