// Copyright (c) 2020, the FSCool project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// license that can be found in the LICENSE file.


import 'dart:async';

import 'package:meta/meta.dart';
import 'package:bloc/bloc.dart';
import 'package:skool/login/SKRegistrationState.dart';
import 'package:skool/login/SKRegisterationEvent.dart';

import 'SKAuthenticationEvent.dart';
import 'SKAuthenticationState.dart';
import 'SKUserRepository.dart';

class SKRegistrationBloc
    extends Bloc<SKRegistrationEvent, SKRegistrationState> {
  final SKUserRepository userRepository;

  SKRegistrationBloc({@required this.userRepository})
      : assert(userRepository != null);

  @override
  SKRegistrationState get initialState => SKRegistrationUninitialized();

  @override
  Stream<SKRegistrationState> mapEventToState(
      SKRegistrationEvent event,
      ) async* {
    if (event is SKRegistrationStarted) {

    }

    if (event is SKRegistrationStarted) {
      yield SKRegisteringLoading();
    }

    if(event is SKRegistrationPerformed) {
      yield SKRegistered();
    }
  }
}
