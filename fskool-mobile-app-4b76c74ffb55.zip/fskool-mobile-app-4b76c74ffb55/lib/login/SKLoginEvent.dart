// Copyright (c) 2020, the FSCool project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// license that can be found in the LICENSE file.


import 'package:meta/meta.dart';
import 'package:equatable/equatable.dart';

abstract class SKLoginEvent extends Equatable {
}

class SKLoginButtonPressed extends SKLoginEvent {
  final String username;
  final String password;

  SKLoginButtonPressed({
    @required this.username,
    @required this.password,
  });

  @override
  List<Object> get props => [username, password];

  @override
  String toString() =>
      'LoginButtonPressed { username: $username, password: $password }';
}