// Copyright (c) 2020, the FSCool project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// license that can be found in the LICENSE file.


import 'dart:async';

import 'package:meta/meta.dart';
import 'package:bloc/bloc.dart';

import 'SKAuthenticationBloc.dart';
import 'SKAuthenticationEvent.dart';
import 'SKLoginEvent.dart';
import 'SKLoginState.dart';
import 'SKUserRepository.dart';

class SKLoginBloc extends Bloc<SKLoginEvent, SKLoginState> {
  final SKUserRepository userRepository;
  final SKAuthenticationBloc authenticationBloc;

  SKLoginBloc({
    @required this.userRepository,
    @required this.authenticationBloc,
  })  : assert(userRepository != null),
        assert(authenticationBloc != null);

  @override
  SKLoginState get initialState => SKLoginInitial();

  @override
  Stream<SKLoginState> mapEventToState(
    SKLoginEvent event,
  ) async* {
    if (event is SKLoginButtonPressed) {
      yield SKLoginLoading();

      try {
        final token = await userRepository.authenticate(
          username: event.username,
          password: event.password,
        );
        authenticationBloc.dispatch(SKLoggedIn(token: token));
        yield SKLoginInitial();
      } catch (error) {
        yield SKLoginFailure(error: error.toString());
      }
    }
  }
}
