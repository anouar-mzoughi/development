// Copyright (c) 2020, the FSCool project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// Full license can be found in the LICENSE file.

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_keychain/flutter_keychain.dart';
import 'package:http/http.dart' as http;

class SKUserRepository {
  final String url = "http://h2896830.stratoserver.net:8080";
  final String url_l = "localhost:8080";

  Future<String> authenticate({
    @required String username,
    @required String password,
  }) async {
    final response =
        await http.get(url + "/login?userId=$username&password=$password");
    print(response.body);
    if (response.statusCode == 200) {
      return response.body;
    }
    throw Exception("not authenticated!");
  }

  Future<void> deleteToken() async {
    /// delete from keystore/keychain
    await Future.delayed(Duration(seconds: 1));
    await FlutterKeychain.remove(key: "token");
    return;
  }

  Future<void> persistToken(String token) async {
    /// write to keystore/keychain
    await Future.delayed(Duration(seconds: 1));
    await FlutterKeychain.put(key: "token", value: token);
    return;
  }

  Future<bool> hasToken() async {
    /// read from keystore/keychain
    await Future.delayed(Duration(seconds: 1));
    var token = await FlutterKeychain.get(key: "token");
    return token != null;
  }

  Future<http.Response> registerUser({username, password}) async {
    var response = http.post(
      url + "/register/",
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode({
        'login': username,
        'password': password,
        'firstName': '',
        'lastName': '',
        'mail': username,
      }),
    );

    return response;
  }
}
