// Copyright (c) 2020, the FSCool project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// license that can be found in the LICENSE file.

import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:skool/ui/SKSplashScreen.dart';
import 'package:skool/ui/widgets/SKLoadingIndicator.dart';
import 'login/SKAuthenticationBloc.dart';
import 'login/SKAuthenticationEvent.dart';
import 'login/SKAuthenticationState.dart';
import 'login/SKUserRepository.dart';
import 'ui/SKLoginScreen.dart';
import 'ui/SKHomeScreen.dart';

void main() {
  BlocSupervisor().delegate = SKSimpleBlocDelegate();
  runApp(SKSCoolApp(
    userRepository: SKUserRepository(),
  ));
}

class SKSimpleBlocDelegate extends BlocDelegate {
  @override
  void onTransition(Transition transition) {
    super.onTransition(transition);
    print(transition.toString());
  }
}

class SKSCoolApp extends StatefulWidget {
  final SKUserRepository userRepository;

  SKSCoolApp({Key key, @required this.userRepository}) : super(key: key);

  @override
  State<SKSCoolApp> createState() => _AppState();
}

class _AppState extends State<SKSCoolApp> {
  SKAuthenticationBloc authenticationBloc;

  SKUserRepository get userRepository => widget.userRepository;

  @override
  void initState() {
    authenticationBloc = SKAuthenticationBloc(userRepository: userRepository);
    authenticationBloc.dispatch(SKAppStarted());
    super.initState();
  }

  @override
  void dispose() {
    authenticationBloc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider<SKAuthenticationBloc>(
      bloc: authenticationBloc,
      child: MaterialApp(
        title: 'SCool',
        theme: ThemeData(
          // This is the theme of your application.
          //
          // Try running your application with "flutter run". You'll see the
          // application has a blue toolbar. Then, without quitting the app, try
          // changing the primarySwatch below to Colors.green and then invoke
          // "hot reload" (press "r" in the console where you ran "flutter run",
          // or simply save your changes to "hot reload" in a Flutter IDE).
          // Notice that the counter didn't reset back to zero; the application
          // is not restarted.
          primarySwatch: Colors.blue,

          // This makes the visual density adapt to the platform that you run
          // the app on. For desktop platforms, the controls will be smaller and
          // closer together (more dense) than on mobile platforms.
          visualDensity: VisualDensity.adaptivePlatformDensity,
        ),
        routes: {
          '/home': (context) => SKHomeScreen(),
          '/login': (context) => SKLoginScreen(userRepository: userRepository),
        },
        home: BlocBuilder<SKAuthenticationEvent, SKAuthenticationState>(
          bloc: authenticationBloc,
          builder: (BuildContext context, SKAuthenticationState state) {
            if (state is SKAuthenticationUninitialized) {
              return SKSplashPage();
            }
            if (state is SKAuthenticationAuthenticated) {
              return SKHomeScreen();
            }
            if (state is SKAuthenticationUnauthenticated) {
              return SKLoginScreen(userRepository: userRepository);
            }
            if (state is SKAuthenticationLoading) {
              return SKLoadingIndicator();
            }

            return null;
          },
        ),
      ),
    );
  }
}
