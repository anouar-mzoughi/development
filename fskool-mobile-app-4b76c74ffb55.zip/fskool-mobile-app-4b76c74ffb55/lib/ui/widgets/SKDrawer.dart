// Copyright (c) 2020, the FSCool project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// license that can be found in the LICENSE file.

import 'package:flutter/material.dart';
import '../SKLoginScreen.dart';

class SKDrawer extends StatelessWidget {
  GestureTapCallback _logOutHandler;

  SKDrawer({Key key, BuildContext context, @required GestureTapCallback logOutHandler}) : super(key: key) {
    _logOutHandler = logOutHandler;
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
        child: ListView(
      padding: EdgeInsets.zero,
      children: <Widget>[
        createHeader(), // Creates the drawer Header
        createDrawerItem(
          icon: Icons.settings,
          text: "Profile",
        ),
        Divider(),
        createDrawerItem(
          icon: Icons.logout,
          text: "Ausloggen",
          onTap: _logOutHandler,
        ),
      ],
    ));
  }

  Widget createHeader() {
    return DrawerHeader(
        margin: EdgeInsets.zero,
        padding: EdgeInsets.zero,
        decoration: BoxDecoration(
            image: DecorationImage(
                fit: BoxFit.fill,
                image: AssetImage('res/drawer_header_background.png'))),
        child: Stack(children: <Widget>[
          Positioned(
              bottom: 12.0,
              left: 16.0,
              child: Text("Max Mustermann",
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 20.0,
                      fontWeight: FontWeight.w500))),
        ]));
  }

  Widget createDrawerItem(
      {IconData icon, String text, GestureTapCallback onTap}) {
    return ListTile(
      title: Row(
        children: <Widget>[
          Icon(icon),
          Padding(
            padding: EdgeInsets.only(left: 8.0),
            child: Text(text),
          )
        ],
      ),
      onTap: onTap,
    );
  }
}
