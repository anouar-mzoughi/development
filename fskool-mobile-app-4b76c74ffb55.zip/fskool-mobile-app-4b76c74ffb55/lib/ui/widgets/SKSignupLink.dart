// Copyright (c) 2020, the FSCool project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// license that can be found in the LICENSE file.

import 'package:flutter/material.dart';
import 'package:skool/login/SKSignUpBlock.dart';
import 'package:skool/login/SKUserRepository.dart';

import 'SKEmailTextField.dart';
import 'SKPasswordTextField.dart';
import 'SKSignUpButton.dart';

class SKSignupLink extends StatelessWidget {
  final SKUserRepository userRepository;
  final SKSignUpBloc signUpBlock;

  SKSignupLink(
      {Key key, @required this.userRepository, @required this.signUpBlock})
      : assert(userRepository != null),
        assert(signUpBlock != null),
        super(key: key);

  @override
  Widget build(BuildContext context) {
    return FlatButton(
      padding: const EdgeInsets.only(
        top: 120.0,
      ),
      onPressed: () => _showRegisterSheet(context),
      child: new Text(
        "Don't have an account? Sign Up",
        textAlign: TextAlign.center,
        overflow: TextOverflow.ellipsis,
        softWrap: true,
        style: TextStyle(
            fontWeight: FontWeight.w400,
            letterSpacing: 0.5,
            color: Colors.white,
            fontSize: 14.0),
      ),
    );
  }

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController = TextEditingController();

  void _showRegisterSheet(context) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext bc) => Container(
        color: Colors.cyan,
        padding: EdgeInsets.only(left: 20, right: 20, bottom: 20),
        child: Column(
          children: <Widget>[
            SKEmailTextField(
              hint: "Username",
              controller: _emailController,
            ),
            SKPasswordTextField(
              hint: "Password",
              controller: _passwordController,
            ),
            SKPasswordTextField(
              hint: "Password bestätigen",
            ),
            Spacer(),
            SKSignUpButton(
              userRepository: userRepository,
              signUpBlock: signUpBlock,
              emailController: _emailController,
              passwordController: _passwordController,
              confirmPasswordController : _confirmPasswordController,
              scaffoldContext: context,
            ),
          ],
        ),
      ),
    );
  }

  _performSignUp(BuildContext context) {}
}
