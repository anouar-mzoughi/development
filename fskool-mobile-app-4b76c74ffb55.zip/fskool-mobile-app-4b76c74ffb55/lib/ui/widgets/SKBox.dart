// Copyright (c) 2020, the FSCool project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// license that can be found in the LICENSE file.
// Copyright (c) 2020, the FSCool project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// license that can be found in the LICENSE file.

import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

class SKBox extends StatefulWidget {
  String _label;

  SKBox({Key key, String label}) : super(key: key) {
    _label = label;
  }

  @override
  _SKBoxState createState() => _SKBoxState();
}

class _SKBoxState extends State<SKBox> {
  int _newMessages;

  _SKBoxState({int newMessages = 0}) {
    _newMessages = newMessages;
  }

  @override
  Widget build(BuildContext context) {
    Widget w = _buildBoxWithNotification();
    return w;
  }

  Container _buildBoxWithNotification() {
    return Container(
        width: 320,
        child: Stack(
          children: <Widget>[
            CupertinoButton(
              child: Container(
                height: 200,
                width: 320,
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage("res/schulplaner.png"),
                        fit: BoxFit.cover),
                    borderRadius: BorderRadius.circular(12)),
                child: Container(
                  margin: EdgeInsets.fromLTRB(15, 15, 0, 0),
                  child: Text(
                    widget._label,
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.w600),
                  ),
                ),
              ),
              onPressed: _incrementCounter,
            ),
            if (_newMessages > 0)
              Positioned(
                  top: 0,
                  right: 0,
                  child: Icon(
                    Icons.messenger,
                    size: 40,
                    color: Colors.redAccent,
                  )),
            if (_newMessages > 0)
              Positioned(
                  top: 8,
                  right: 10,
                  child: Text(
                    '$_newMessages',
                    style: TextStyle(
                        fontSize: 15,
                        color: Colors.white,
                        fontWeight: FontWeight.w500),
                  ))
          ],
        ));
  }

  void _incrementCounter() {
    setState(() {
      _newMessages++;
    });
  }
}
