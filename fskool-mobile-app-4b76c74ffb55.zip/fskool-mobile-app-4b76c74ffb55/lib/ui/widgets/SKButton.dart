// Copyright (c) 2020, the FSCool project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// license that can be found in the LICENSE file.

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class SKButton extends StatefulWidget {
  final String label;

  SKButton(String label) : this.label = label;

  @override
  State<StatefulWidget> createState() {
    return _SKButtonState();
  }

  handleTap(BuildContext context)  {}
}

class _SKButtonState extends State<SKButton> {
  bool actionLoading;

  @override
  void initState() {
    actionLoading = false;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return actionLoading
        ? CircularProgressIndicator()
        : InkWell(
            onTap: () => _handleTap(context),
            child: Container(
              width: 320.0,
              height: 60.0,
              alignment: FractionalOffset.center,
              decoration: BoxDecoration(
                color: const Color.fromRGBO(255, 149, 0, 1),
                borderRadius: BorderRadius.all(const Radius.circular(10.0)),
              ),
              child: Text(
                widget.label,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20.0,
                  fontWeight: FontWeight.w300,
                  letterSpacing: 0.3,
                ),
              ),
            ),
          );
  }

  _handleTap(BuildContext ctx) async {
    setState(() {
      actionLoading = true;
    });
    await Future.delayed(Duration(seconds: 1));
    widget.handleTap(context);
    setState(() {
      actionLoading = false;
    });
    await Future.delayed(Duration(milliseconds: 500));
  }
}
