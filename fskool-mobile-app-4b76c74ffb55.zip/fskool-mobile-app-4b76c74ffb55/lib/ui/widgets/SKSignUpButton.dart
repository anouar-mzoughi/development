// Copyright (c) 2020, the FSCool project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// license that can be found in the LICENSE file.

import 'package:email_validator/email_validator.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:skool/login/SKSignUpBlock.dart';
import 'package:skool/login/SKSignUpEvent.dart';
import 'package:skool/login/SKUserRepository.dart';
import 'package:skool/ui/widgets/SKButton.dart';

class SKSignUpButton extends SKButton {
  final SKUserRepository userRepository;
  final SKSignUpBloc signUpBlock;
  final BuildContext scaffoldContext;

  final TextEditingController emailController;
  final TextEditingController passwordController;
  final TextEditingController confirmPasswordController;

  SKSignUpButton({
    @required this.userRepository,
    @required this.signUpBlock,
    @required this.emailController,
    @required this.passwordController,
    @required this.scaffoldContext,
    @required this.confirmPasswordController,
  }) : super("Sign Up");

  @override
  handleTap(BuildContext context) {
    String email = emailController.text;
    String password = passwordController.text;
    String confirmation = confirmPasswordController.text;
    String error;
    if (!EmailValidator.validate(email)) {
      error = "invalid Email !";
    }

    if( password == null||
        password.length > 5 ) {
      error = "invalid Password (more than 5 characters) !";
    }

    if(password != confirmation) {
      error = "Password & confirmation does not match !";
    }

    if(error != null && error.length > 0) {
      Navigator.pop(context);
      Scaffold.of(scaffoldContext).showSnackBar(
        SnackBar(
          backgroundColor: Color.fromRGBO(255, 45, 85, 1),
          behavior: SnackBarBehavior.floating,
          content: Text(error),
        ),
      );
    } else {
      signUpBlock
          .dispatch(SKSignUpButtonPressed(username: email, password: password));
      Navigator.pop(context);
      Scaffold.of(scaffoldContext).showSnackBar(
        SnackBar(
          backgroundColor: Color.fromRGBO(52, 199, 89, 1),
          behavior: SnackBarBehavior.floating,
          content: Text("Registered !"),
        ),
      );
    }
  }
}
