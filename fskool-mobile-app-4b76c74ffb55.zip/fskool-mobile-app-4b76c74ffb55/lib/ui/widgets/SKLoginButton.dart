// Copyright (c) 2020, the FSCool project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// license that can be found in the LICENSE file.

import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:skool/login/SKLoginBloc.dart';
import 'package:skool/login/SKLoginEvent.dart';
import 'package:skool/login/SKLoginState.dart';
import 'package:skool/ui/widgets/SKButton.dart';

class SKLoginButton extends SKButton {
  final SKLoginState state;
  final SKLoginBloc loginBloc;
  final TextEditingController emailController;
  final TextEditingController passwordController;

  SKLoginButton(
      SKLoginState state,
      SKLoginBloc loginBloc,
      TextEditingController emailController,
      TextEditingController passwordController)
      : this.state = state,
        this.loginBloc = loginBloc,
        this.emailController = emailController,
        this.passwordController = passwordController,
        super("Sign In");

  @override
  handleTap(BuildContext context) {
    if (state is! SKLoginLoading) {
      _onLoginButtonPressed(context);
    }
  }

  void _onLoginButtonPressed(BuildContext context) {
    String email = emailController.text;
    String password = passwordController.text;
    if (EmailValidator.validate(email) &&
        password != null &&
        password.length > 5) {
      loginBloc
          .dispatch(SKLoginButtonPressed(username: email, password: password));
    } else {
      Scaffold.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Color.fromRGBO(255, 45, 85, 1),
          behavior: SnackBarBehavior.floating,
          content: Text("Invalid Login / password !"),
        ),
      );
    }
  }
}
