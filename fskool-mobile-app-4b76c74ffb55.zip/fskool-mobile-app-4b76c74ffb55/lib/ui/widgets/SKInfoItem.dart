// Copyright (c) 2020, the FSCool project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// license that can be found in the LICENSE file.


import 'package:flutter/material.dart';

class SKInfoItem extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(
          vertical: 5.0, horizontal: 10.0),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: Container(
          height: 70,
          color: Colors.white,
          child: Row(
            children: <Widget>[
              Container(
                color: Colors.amber,
                width: 70,
                height: 70,
                child: Icon(Icons.mail, color: Colors.white),
              ),
              SizedBox(width: 10),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment:
                  CrossAxisAlignment.start,
                  children: <Widget>[
                    Text('Message Title'),
                    Text('Short message description to see what is importenatn',
                        style: TextStyle(color: Colors.grey))
                  ],
                ),
              ),
              Icon(Icons.arrow_forward_ios,
                  color: Colors.redAccent),
            ],
          ),
        ),
      ),
    );
  }
}
