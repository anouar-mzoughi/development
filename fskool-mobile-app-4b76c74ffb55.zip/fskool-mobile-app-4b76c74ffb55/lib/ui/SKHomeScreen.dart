// Copyright (c) 2020, the FSCool project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// license that can be found in the LICENSE file.


import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';

import 'package:flutter_bloc/flutter_bloc.dart';

import 'widgets/SKDrawer.dart';
import 'widgets/SKInfoItem.dart';

import '../login/SKAuthenticationBloc.dart';
import '../login/SKAuthenticationEvent.dart';

// factories
import 'factories/SKBoxesFactory.dart';

///
///
class SKHomeScreen extends StatelessWidget {
  SKHomeScreen({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final SKAuthenticationBloc authenticationBloc =
        BlocProvider.of<SKAuthenticationBloc>(context);

    return Scaffold(
      appBar: AppBar(title: const Text('Willkommen')),
      drawer: SKDrawer(logOutHandler: () => _performLogOut(authenticationBloc)),
      body: Column(
        children: [
          Container(
            margin: EdgeInsets.symmetric(vertical: 20.0),
            height: 200,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: <Widget>[
                SKBoxesFactory.createSchulplanerBox(),
                SKBoxesFactory.createSchulMappeBox(),
              ],
            ),
          ),
          Divider(
            indent: 10,
            endIndent: 10,
          ),
          Expanded(
            child: ListView(
              scrollDirection: Axis.vertical,
              padding: const EdgeInsets.all(8),
              children: <Widget>[
                Text("Eilemeldungen",
                    style: Theme.of(context).textTheme.headline5,
                    textAlign: TextAlign.center),
                SKInfoItem(),
                SKInfoItem(),
                Divider(
                  indent: 10,
                  endIndent: 10,
                ),
                Text("Meldungen",
                    style: Theme.of(context).textTheme.headline5,
                    textAlign: TextAlign.center),
                SKInfoItem(),
                SKInfoItem(),
                SKInfoItem(),
                SKInfoItem(),
                SKInfoItem(),
                SKInfoItem(),
                SKInfoItem(),
                SKInfoItem(),
                SKInfoItem(),
                SKInfoItem(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _performLogOut(SKAuthenticationBloc authenticationBloc) {
    authenticationBloc.dispatch(SKLoggedOut());
  }
}
