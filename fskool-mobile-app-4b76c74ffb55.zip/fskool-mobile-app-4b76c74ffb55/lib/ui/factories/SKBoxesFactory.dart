// Copyright (c) 2020, the FSCool project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// license that can be found in the LICENSE file.



import '../widgets/SKBox.dart';

class SKBoxesFactory  {
  static SKBox createSchulplanerBox() {
    return SKBox(label : 'Schulplaner');
  }

  static SKBox createSchulMappeBox() {
    return SKBox(label : 'Mappe');
  }
}