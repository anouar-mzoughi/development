// Copyright (c) 2020, the FSCool project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// license that can be found in the LICENSE file.

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:skool/login/SKLoginEvent.dart';
import 'package:skool/login/SKLoginState.dart';
import 'package:skool/login/SKSignUpBlock.dart';
import 'package:skool/login/SKUserRepository.dart';
import 'package:skool/login/SKLoginBloc.dart';
import 'package:skool/login/SKAuthenticationBloc.dart';
import 'package:skool/ui/widgets/SKEmailTextField.dart';
import 'package:skool/ui/widgets/SKLoginButton.dart';
import 'package:skool/ui/widgets/SKPasswordTextField.dart';
import 'package:skool/ui/widgets/SKSignupLink.dart';

class SKLoginScreen extends StatefulWidget {
  final SKUserRepository userRepository;

  SKLoginScreen({Key key, @required this.userRepository})
      : assert(userRepository != null),
        super(key: key);

  @override
  State<SKLoginScreen> createState() {
    return SKLoginScreenState();
  }
}

class SKLoginScreenState extends State<SKLoginScreen>
    with TickerProviderStateMixin {
  SKLoginBloc _loginBloc;
  SKAuthenticationBloc _authenticationBloc;
  SKSignUpBloc _signUpBlock;

  SKUserRepository get _userRepository => widget.userRepository;

  @override
  void initState() {
    _authenticationBloc = BlocProvider.of<SKAuthenticationBloc>(context);
    _loginBloc = SKLoginBloc(
      userRepository: _userRepository,
      authenticationBloc: _authenticationBloc,
    );
    _signUpBlock = SKSignUpBloc(
      userRepository: _userRepository,
    );
    super.initState();
  }

  @override
  void dispose() {
    _loginBloc.dispose();
    super.dispose();
  }

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  BuildContext scaffold;

  @override
  Widget build(BuildContext context) {
    scaffold = context;
    return BlocBuilder<SKLoginEvent, SKLoginState>(
      bloc: _loginBloc,
      builder: (BuildContext context, SKLoginState state) {
        if (state is SKLoginFailure) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            Scaffold.of(scaffold).showSnackBar(
              SnackBar(
                content: Text('${state.error}'),
                backgroundColor: Colors.red,
              ),
            );
          });
        }
        return Scaffold(
          body: Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage("res/school.jpg"), fit: BoxFit.fitHeight),
            ),
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: <Color>[
                    Colors.cyan.withOpacity(1.0),
                    const Color.fromRGBO(0, 122, 255, 0.8),
                  ],
                  stops: [0.2, 1.0],
                  begin: const FractionalOffset(0.0, 0.0),
                  end: const FractionalOffset(0.0, 1.0),
                ),
              ),
              child: ListView(
                padding: const EdgeInsets.all(0.0),
                children: <Widget>[
                  Container(
                    height: 100,
                  ),
                  Text(
                    "S.cool!",
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.headline1.copyWith(
                          color: Colors.white54,
                          fontWeight: FontWeight.w300,
                        ),
                  ),
                  Container(
                    height: 100,
                  ),
                  AutofillGroup(
                    child: Container(
                      margin: new EdgeInsets.symmetric(horizontal: 20.0),
                      child: Form(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: <Widget>[
                            SKEmailTextField(
                              hint: "Username",
                              controller: _emailController,
                            ),
                            SKPasswordTextField(
                              hint: "Password",
                              controller: _passwordController,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(bottom: 50.0),
                              child: SKLoginButton(state, _loginBloc,
                                  _emailController, _passwordController),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Stack(
                    alignment: AlignmentDirectional.bottomCenter,
                    children: <Widget>[
                      Column(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          SKSignupLink(
                            userRepository: _userRepository,
                            signUpBlock: _signUpBlock,
                          ),
                        ],
                      ),
                      Container(
                        child: state is SKLoginLoading
                            ? CircularProgressIndicator()
                            : null,
                      ),
                    ],
                  ),
                  Text(
                    "\nAGB | Datenschutz | Hilfe\n Scool Copyright 2020 ©",
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
