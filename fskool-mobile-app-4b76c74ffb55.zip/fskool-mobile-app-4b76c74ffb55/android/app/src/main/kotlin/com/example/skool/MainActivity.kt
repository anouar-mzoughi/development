package com.example.skool

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
