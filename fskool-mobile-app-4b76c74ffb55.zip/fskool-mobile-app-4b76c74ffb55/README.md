# skool

Mobile App to manage the school stuff

## Getting Started

This project is a starting point for a Flutter application.

Before to start working on a Task you have to :

### Do Once

- [Download Flutter SDK](https://flutter.dev/docs/get-started/install)
- [Download the Android Studio](https://developer.android.com/studio)
- Finish the IDE Setup with all packages
- In the IDE Preference point to the Flutter SDK Folder.

### On Each Task

- create A branch from the Master
  * go to the relevant Task
  - go to the "Development" Section (on the Task)
  - click on the plus (+) / "create Branch"
  - Choose fskool/mobile-app as repository
  - choose (Feature) as "Type"
  - from the "Master"
  - keep at least the task number as Branch name
  - click on Create
- Checkout (clone branch) to an empty folder
- Load folder in the IDE

Now Work, Later do not Forget to merge ;)


A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
