package com.skool.data.server.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.skool.data.server.domain.impl.Group;
import com.skool.data.server.domain.projections.GroupWithId;

@RepositoryRestResource(excerptProjection = GroupWithId.class)
public interface GroupRepository extends CrudRepository<Group, Long> {

}
