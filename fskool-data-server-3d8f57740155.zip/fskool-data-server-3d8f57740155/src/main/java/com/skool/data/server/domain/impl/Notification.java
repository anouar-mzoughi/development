package com.skool.data.server.domain.impl;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;

@Entity(name = "skNotification")
public class Notification {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@OneToOne
	private Person sender;

	@ManyToMany
	private List<Group> groupRecievers;

	@ManyToMany
	private List<Person> personRecievers;

	private String title;
	private String content;

	public Notification() {
		// TODO Auto-generated constructor stub
	}

	public Notification(Person sender, String title, String content) {
		super();
		this.sender = sender;
		this.title = title;
		this.content = content;
	}

	public Person getSender() {
		return sender;
	}

	public void setSender(Person sender) {
		this.sender = sender;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<Group> getGroupRecievers() {
		return groupRecievers;
	}

	public void setGroupRecievers(List<Group> groupReciever) {
		this.groupRecievers = groupReciever;
	}

	public List<Person> getPersonRecievers() {
		return personRecievers;
	}

	public void setPersonRecievers(List<Person> personReciever) {
		this.personRecievers = personReciever;
	}
}
