package com.skool.data.server.domain;

public interface IAssignable {

}
