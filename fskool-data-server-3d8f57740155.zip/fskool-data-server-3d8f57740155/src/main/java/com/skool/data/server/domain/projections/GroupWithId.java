package com.skool.data.server.domain.projections;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.rest.core.config.Projection;

import com.skool.data.server.domain.impl.Group;

@Projection(name = "withId", types = { Group.class })
public interface GroupWithId {
	@Value("#{target.id}")
	Long getIdentifier();

	String getName();
}
