package com.skool.data.server.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.skool.data.server.repo.PersonRepository;

@RestController
@RequestMapping("/data")
public class PersonCustomController {
	@Autowired
	PersonRepository repository;

//	@GetMapping("/persons/smartCode/{smartCode}")
//	public Person getPersonByActivationCode(@PathVariable String smartCode) {
//		List<Person> found = repository.findBySmartCode(smartCode);
//		if(found != null && !found.isEmpty()) {
//			return found.iterator().next();
//		}
//		return null;
//	}
}
