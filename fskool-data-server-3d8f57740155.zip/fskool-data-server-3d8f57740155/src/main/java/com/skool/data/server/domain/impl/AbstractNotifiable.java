package com.skool.data.server.domain.impl;

import java.util.List;

import com.skool.data.server.domain.INotifiable;

public abstract class AbstractNotifiable  implements INotifiable {

	private List<Notification> notifications;

	@Override
	public List<Notification> getNotifications() {
		return notifications;
	}

	public void setNotifications(List<Notification> notifications) {
		this.notifications = notifications;
	}
}
