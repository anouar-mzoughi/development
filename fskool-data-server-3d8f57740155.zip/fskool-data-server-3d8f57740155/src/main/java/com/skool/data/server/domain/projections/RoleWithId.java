package com.skool.data.server.domain.projections;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.rest.core.config.Projection;

import com.skool.data.server.domain.impl.Access;

@Projection(name = "withId", types = { RoleWithId.class })
public interface RoleWithId {
	@Value("#{target.id}")
	Long getIdentifier();

	String getName();

	String getDescription();

	List<Access> getAllowedAccesses();

}
