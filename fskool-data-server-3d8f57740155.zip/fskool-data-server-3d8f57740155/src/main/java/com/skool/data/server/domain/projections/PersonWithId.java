package com.skool.data.server.domain.projections;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.rest.core.config.Projection;

import com.skool.data.server.domain.impl.Person;
import com.skool.data.server.domain.impl.Role;
@Projection(name = "withId", types = { Person.class })
public interface PersonWithId {
	
	@Value("#{target.id}")
	Long getIdentifier();
	
	String getFirstName();
	String getLastName();
	String getEmail();
	String getMobile();
	String getAddress();
	Date getBirthday();
	
	List<Role> getRoles();

}
