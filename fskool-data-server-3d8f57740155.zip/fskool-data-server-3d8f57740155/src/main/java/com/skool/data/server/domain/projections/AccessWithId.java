package com.skool.data.server.domain.projections;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.rest.core.config.Projection;

import com.skool.data.server.domain.impl.Access;

@Projection(name = "withId", types = { Access.class })
public interface AccessWithId {
	@Value("#{target.id}")
	Long getIdentifier();
	String getName();
	String getDescription();
}
