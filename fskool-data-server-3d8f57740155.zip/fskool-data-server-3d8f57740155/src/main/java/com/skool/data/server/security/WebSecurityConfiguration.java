package com.skool.data.server.security;

//import javax.servlet.http.HttpServletResponse;

//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
//import org.springframework.security.config.http.SessionCreationPolicy;

// @EnableWebSecurity
public class WebSecurityConfiguration { //extends WebSecurityConfigurerAdapter {

//	@Autowired
//	public WebSecurityConfiguration() {
//	}
//
//	@Autowired
//	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
//		
//	}
//
//	@Override
//	protected void configure(HttpSecurity httpSecurity) throws Exception {
//		httpSecurity.csrf().disable().sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()
//				.exceptionHandling()
//				.authenticationEntryPoint(
//						(request, response, ex) -> response.sendError(HttpServletResponse.SC_UNAUTHORIZED))
//				.and()
//				.authorizeRequests()
//				.antMatchers("/data/**").permitAll()
//				.antMatchers("/").permitAll()
//				.anyRequest().authenticated();
//	}
}