package com.skool.data.server.domain;
import java.util.List;
import com.skool.data.server.domain.impl.Notification;

public interface INotifiable {
	
	List<Notification> getNotifications();

}
