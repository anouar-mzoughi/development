package com.skool.data.server.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.skool.data.server.domain.impl.Person;
import com.skool.data.server.domain.projections.PersonWithId;

@RepositoryRestResource(excerptProjection = PersonWithId.class)
public interface PersonRepository extends CrudRepository<Person, Long> {

}
