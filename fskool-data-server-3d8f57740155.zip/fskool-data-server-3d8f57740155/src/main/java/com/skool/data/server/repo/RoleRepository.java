package com.skool.data.server.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.skool.data.server.domain.impl.Role;
import com.skool.data.server.domain.projections.RoleWithId;

@RepositoryRestResource(excerptProjection = RoleWithId.class)
public interface RoleRepository extends CrudRepository<Role, Long> {

}
