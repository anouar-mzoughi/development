package com.skool.data.server.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.skool.data.server.domain.impl.Access;
import com.skool.data.server.domain.projections.AccessWithId;

@RepositoryRestResource(excerptProjection = AccessWithId.class)
public interface AccessRepository extends CrudRepository<Access, Long>{

}
