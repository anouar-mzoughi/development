package com.skool.data.server.repo;

import org.springframework.data.repository.CrudRepository;

import com.skool.data.server.domain.impl.Task;

public interface TaskRepository extends CrudRepository<Task, Long> {

}
