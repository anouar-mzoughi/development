package com.skool.data.server.repo;

import org.springframework.data.repository.CrudRepository;

import com.skool.data.server.domain.impl.Notification;

public interface NotificationRepository extends CrudRepository<Notification, Long> {

}
